var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/handlers.ts
var handlers_exports = {};
__export(handlers_exports, {
  contact: () => contact,
  createArticle: () => createArticle,
  createCategory: () => createCategory,
  createUser: () => createUser,
  deleteArticle: () => deleteArticle,
  deleteCategory: () => deleteCategory,
  deleteUser: () => deleteUser,
  getAllTags: () => getAllTags,
  getArticleById: () => getArticleById,
  getArticleBySlug: () => getArticleBySlug,
  getArticles: () => getArticles,
  getCategories: () => getCategories,
  getNotificationsForUser: () => getNotificationsForUser,
  getPendingComments: () => getPendingComments,
  getSubscribers: () => getSubscribers,
  getUser: () => getUser,
  getUsers: () => getUsers,
  login: () => login,
  postComment: () => postComment,
  register: () => register,
  subscribe: () => subscribe,
  updateArticle: () => updateArticle,
  updateArticleStatus: () => updateArticleStatus,
  updateCategory: () => updateCategory,
  updateCommentStatus: () => updateCommentStatus,
  updateFeaturedStatus: () => updateFeaturedStatus,
  updateUser: () => updateUser
});
module.exports = __toCommonJS(handlers_exports);

// node_modules/uuid/dist/esm-node/rng.js
var import_crypto = __toESM(require("crypto"));
var rnds8Pool = new Uint8Array(256);
var poolPtr = rnds8Pool.length;
function rng() {
  if (poolPtr > rnds8Pool.length - 16) {
    import_crypto.default.randomFillSync(rnds8Pool);
    poolPtr = 0;
  }
  return rnds8Pool.slice(poolPtr, poolPtr += 16);
}

// node_modules/uuid/dist/esm-node/stringify.js
var byteToHex = [];
for (let i = 0; i < 256; ++i) {
  byteToHex.push((i + 256).toString(16).slice(1));
}
function unsafeStringify(arr, offset = 0) {
  return byteToHex[arr[offset + 0]] + byteToHex[arr[offset + 1]] + byteToHex[arr[offset + 2]] + byteToHex[arr[offset + 3]] + "-" + byteToHex[arr[offset + 4]] + byteToHex[arr[offset + 5]] + "-" + byteToHex[arr[offset + 6]] + byteToHex[arr[offset + 7]] + "-" + byteToHex[arr[offset + 8]] + byteToHex[arr[offset + 9]] + "-" + byteToHex[arr[offset + 10]] + byteToHex[arr[offset + 11]] + byteToHex[arr[offset + 12]] + byteToHex[arr[offset + 13]] + byteToHex[arr[offset + 14]] + byteToHex[arr[offset + 15]];
}

// node_modules/uuid/dist/esm-node/native.js
var import_crypto2 = __toESM(require("crypto"));
var native_default = {
  randomUUID: import_crypto2.default.randomUUID
};

// node_modules/uuid/dist/esm-node/v4.js
function v4(options, buf, offset) {
  if (native_default.randomUUID && !buf && !options) {
    return native_default.randomUUID();
  }
  options = options || {};
  const rnds = options.random || (options.rng || rng)();
  rnds[6] = rnds[6] & 15 | 64;
  rnds[8] = rnds[8] & 63 | 128;
  if (buf) {
    offset = offset || 0;
    for (let i = 0; i < 16; ++i) {
      buf[offset + i] = rnds[i];
    }
    return buf;
  }
  return unsafeStringify(rnds);
}
var v4_default = v4;

// src/mockData.ts
var users = [
  { id: "u1", name: "\u0BA8\u0BBF\u0BB0\u0BCD\u0BB5\u0BBE\u0B95 \u0BAA\u0BAF\u0BA9\u0BB0\u0BCD", email: "admin@news.com", role: "ADMIN" /* ADMIN */, avatarUrl: "https://picsum.photos/seed/u1/100/100", bio: "Responsible for site administration and content oversight." },
  { id: "u2", name: "\u0B86\u0B9A\u0BBF\u0BB0\u0BBF\u0BAF\u0BB0\u0BCD \u0B8E\u0BB0\u0BBF\u0B95\u0BCD\u0B95\u0BBE", email: "editor@news.com", role: "EDITOR" /* EDITOR */, avatarUrl: "https://picsum.photos/seed/u2/100/100", bio: "Experienced editor with a keen eye for detail and a passion for quality journalism." },
  { id: "u3", name: "\u0B86\u0B9A\u0BBF\u0BB0\u0BBF\u0BAF\u0BB0\u0BCD \u0B85\u0BB0\u0BC1\u0BA3\u0BCD", email: "author@news.com", role: "AUTHOR" /* AUTHOR */, avatarUrl: "https://picsum.photos/seed/u3/100/100", bio: "Technology correspondent covering AI, machine learning, and innovation." },
  { id: "u4", name: "\u0B9A\u0BC6\u0BAF\u0BCD\u0BA4\u0BBF\u0BAF\u0BBE\u0BB3\u0BB0\u0BCD \u0BB0\u0BC0\u0B9F\u0BCD\u0B9F\u0BBE", email: "reporter@news.com", role: "AUTHOR" /* AUTHOR */, avatarUrl: "https://picsum.photos/seed/u4/100/100", bio: "Financial reporter specializing in global markets and economic policy." },
  { id: "u5", name: "\u0B86\u0B9A\u0BBF\u0BB0\u0BBF\u0BAF\u0BB0\u0BCD \u0BAA\u0BBF\u0BB0\u0BBF\u0BAF\u0BBE", email: "editor2@news.com", role: "EDITOR" /* EDITOR */, avatarUrl: "https://picsum.photos/seed/u5/100/100", bio: "Lead editor for the politics and world news sections." },
  { id: "u6", name: "\u0B95\u0B9F\u0BCD\u0B9F\u0BC1\u0BB0\u0BC8\u0BAF\u0BBE\u0BB3\u0BB0\u0BCD \u0BB0\u0BB5\u0BBF", email: "author2@news.com", role: "AUTHOR" /* AUTHOR */, avatarUrl: "https://picsum.photos/seed/u6/100/100", bio: "Investigative journalist with a focus on environmental and climate change stories." },
  { id: "u7", name: "\u0BA8\u0BBF\u0BB0\u0BC1\u0BAA\u0BB0\u0BCD \u0B9A\u0BC1\u0BA9\u0BBF\u0BA4\u0BBE", email: "reporter2@news.com", role: "AUTHOR" /* AUTHOR */, avatarUrl: "https://picsum.photos/seed/u7/100/100", bio: "Entertainment and cinema critic, following the latest trends in the film industry." }
];
var categories = [
  { id: "c1", name: "Technology", slug: "technology" },
  { id: "c2", name: "Business", slug: "business" },
  { id: "c3", name: "Politics", slug: "politics" },
  { id: "c4", name: "Sports", slug: "sports" },
  { id: "c5", name: "Health", slug: "health" },
  { id: "c6", name: "World", slug: "world" },
  { id: "c7", name: "Cinema", slug: "cinema" },
  { id: "c8", name: "Lifestyle", slug: "lifestyle" },
  { id: "c9", name: "Science", slug: "science" }
];
var articles = [
  // Published Articles (More for homepage)
  {
    id: "a1",
    title: "\u0B9A\u0BC6\u0BAF\u0BB1\u0BCD\u0B95\u0BC8 \u0BA8\u0BC1\u0BA3\u0BCD\u0BA3\u0BB1\u0BBF\u0BB5\u0BBF\u0BA9\u0BCD \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0B95\u0BBE\u0BB2\u0BAE\u0BCD: 2024 \u0B87\u0BB2\u0BCD \u0B95\u0BB5\u0BA9\u0BBF\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BBF\u0BAF \u0BAA\u0BCB\u0B95\u0BCD\u0B95\u0BC1\u0B95\u0BB3\u0BCD",
    slug: "future-of-ai-2024",
    summary: "\u0B9A\u0BC6\u0BAF\u0BB1\u0BCD\u0B95\u0BC8 \u0BA8\u0BC1\u0BA3\u0BCD\u0BA3\u0BB1\u0BBF\u0BB5\u0BC1 \u0BAE\u0BC1\u0BA9\u0BCD\u0BA9\u0BC6\u0BAA\u0BCD\u0BAA\u0BCB\u0BA4\u0BC1\u0BAE\u0BCD \u0B87\u0BB2\u0BCD\u0BB2\u0BBE\u0BA4 \u0BB5\u0BC7\u0B95\u0BA4\u0BCD\u0BA4\u0BBF\u0BB2\u0BCD \u0BB5\u0BB3\u0BB0\u0BCD\u0BA8\u0BCD\u0BA4\u0BC1 \u0BB5\u0BB0\u0BC1\u0B95\u0BBF\u0BB1\u0BA4\u0BC1. \u0B87\u0BA8\u0BCD\u0BA4 \u0B86\u0BA3\u0BCD\u0B9F\u0BC1 \u0BA4\u0BCA\u0BB4\u0BBF\u0BB2\u0BCD\u0BA4\u0BC1\u0BB1\u0BC8\u0BAF\u0BC8 \u0BB5\u0B9F\u0BBF\u0BB5\u0BAE\u0BC8\u0B95\u0BCD\u0B95\u0BC1\u0BAE\u0BCD \u0BAE\u0BC1\u0B95\u0BCD\u0B95\u0BBF\u0BAF \u0BAA\u0BCB\u0B95\u0BCD\u0B95\u0BC1\u0B95\u0BB3\u0BCD \u0B87\u0B99\u0BCD\u0B95\u0BC7.",
    content: "<p>\u0B9A\u0BC6\u0BAF\u0BB1\u0BCD\u0B95\u0BC8 \u0BA8\u0BC1\u0BA3\u0BCD\u0BA3\u0BB1\u0BBF\u0BB5\u0BC1 (AI) \u0B89\u0BB2\u0B95\u0BAE\u0BCD \u0BA8\u0BBF\u0BB2\u0BC8\u0BAF\u0BBE\u0BA9 \u0BAE\u0BBE\u0BB1\u0BCD\u0BB1\u0BA4\u0BCD\u0BA4\u0BBF\u0BB2\u0BCD \u0B89\u0BB3\u0BCD\u0BB3\u0BA4\u0BC1. \u0BA8\u0BBE\u0BAE\u0BCD 2024 \u0B87\u0BB2\u0BCD \u0BAE\u0BC7\u0BB2\u0BC1\u0BAE\u0BCD \u0BAE\u0BC1\u0BA9\u0BCD\u0BA9\u0BC7\u0BB1\u0BC1\u0BAE\u0BCD\u0BAA\u0BCB\u0BA4\u0BC1, \u0BA4\u0BCA\u0BB4\u0BBF\u0BB2\u0BCD\u0B95\u0BB3\u0BC8\u0BAF\u0BC1\u0BAE\u0BCD \u0BA8\u0BAE\u0BA4\u0BC1 \u0B85\u0BA9\u0BCD\u0BB1\u0BBE\u0B9F \u0BB5\u0BBE\u0BB4\u0BCD\u0B95\u0BCD\u0B95\u0BC8\u0BAF\u0BC8\u0BAF\u0BC1\u0BAE\u0BCD \u0BAE\u0BB1\u0BC1\u0BB5\u0BB0\u0BC8\u0BAF\u0BB1\u0BC8 \u0B9A\u0BC6\u0BAF\u0BCD\u0BB5\u0BA4\u0BBE\u0B95 \u0B89\u0BB1\u0BC1\u0BA4\u0BBF\u0BAF\u0BB3\u0BBF\u0B95\u0BCD\u0B95\u0BC1\u0BAE\u0BCD \u0BAA\u0BB2 \u0BAE\u0BC1\u0B95\u0BCD\u0B95\u0BBF\u0BAF \u0BAA\u0BCB\u0B95\u0BCD\u0B95\u0BC1\u0B95\u0BB3\u0BCD \u0BB5\u0BC6\u0BB3\u0BBF\u0BB5\u0BB0\u0BC1\u0B95\u0BBF\u0BA9\u0BCD\u0BB1\u0BA9...</p>",
    coverImageUrl: "https://picsum.photos/seed/a1/800/400",
    authorId: "u3",
    categoryId: "c1",
    tags: ["AI", "\u0B87\u0BAF\u0BA8\u0BCD\u0BA4\u0BBF\u0BB0 \u0B95\u0BB1\u0BCD\u0BB1\u0BB2\u0BCD", "\u0BAA\u0BC1\u0BA4\u0BCD\u0BA4\u0BBE\u0B95\u0BCD\u0B95\u0BAE\u0BCD"],
    status: "Published" /* PUBLISHED */,
    publishedAt: "2024-07-22T10:00:00Z",
    views: 25203,
    isFeatured: true,
    comments: [
      { id: "com1", authorName: "\u0BA4\u0BCA\u0BB4\u0BBF\u0BB2\u0BCD\u0BA8\u0BC1\u0B9F\u0BCD\u0BAA \u0B86\u0BB0\u0BCD\u0BB5\u0BB2\u0BB0\u0BCD", authorAvatarUrl: "https://picsum.photos/seed/com1/50/50", text: "\u0B9A\u0BBF\u0BB1\u0BA8\u0BCD\u0BA4 \u0B95\u0BA3\u0BCD\u0BA3\u0BCB\u0B9F\u0BCD\u0B9F\u0BAE\u0BCD!", date: "2024-07-22T12:30:00Z", status: "APPROVED" }
    ],
    videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ"
  },
  {
    id: "a2",
    title: "\u0BAA\u0BC1\u0BA4\u0BBF\u0BAF \u0BAA\u0BCA\u0BB0\u0BC1\u0BB3\u0BBE\u0BA4\u0BBE\u0BB0\u0B95\u0BCD \u0B95\u0BCA\u0BB3\u0BCD\u0B95\u0BC8\u0B95\u0BB3\u0BC1\u0B95\u0BCD\u0B95\u0BC1 \u0B89\u0BB2\u0B95\u0B9A\u0BCD \u0B9A\u0BA8\u0BCD\u0BA4\u0BC8\u0B95\u0BB3\u0BCD \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BB5\u0BBF\u0BA9\u0BC8",
    slug: "global-markets-react",
    summary: "\u0B9A\u0BAE\u0BC0\u0BAA\u0BA4\u0BCD\u0BA4\u0BBF\u0BAF \u0B95\u0BCA\u0BB3\u0BCD\u0B95\u0BC8 \u0BAE\u0BBE\u0BB1\u0BCD\u0BB1\u0B99\u0BCD\u0B95\u0BB3\u0BCD \u0BB5\u0BCB\u0BB2\u0BCD \u0BB8\u0BCD\u0B9F\u0BCD\u0BB0\u0BC0\u0B9F\u0BCD \u0BAE\u0BC1\u0BA4\u0BB2\u0BCD \u0B9F\u0BCB\u0B95\u0BCD\u0B95\u0BBF\u0BAF\u0BCB \u0BB5\u0BB0\u0BC8 \u0B89\u0BB2\u0B95\u0BC6\u0B99\u0BCD\u0B95\u0BBF\u0BB2\u0BC1\u0BAE\u0BCD \u0B89\u0BB3\u0BCD\u0BB3 \u0BAA\u0B99\u0BCD\u0B95\u0BC1\u0B9A\u0BCD \u0B9A\u0BA8\u0BCD\u0BA4\u0BC8\u0B95\u0BB3\u0BC8 \u0B8E\u0BB5\u0BCD\u0BB5\u0BBE\u0BB1\u0BC1 \u0BAA\u0BBE\u0BA4\u0BBF\u0B95\u0BCD\u0B95\u0BBF\u0BA9\u0BCD\u0BB1\u0BA9 \u0B8E\u0BA9\u0BCD\u0BAA\u0BA4\u0BC1 \u0B95\u0BC1\u0BB1\u0BBF\u0BA4\u0BCD\u0BA4 \u0B86\u0BB4\u0BAE\u0BBE\u0BA9 \u0BAA\u0BBE\u0BB0\u0BCD\u0BB5\u0BC8.",
    content: "<p>\u0B95\u0B9F\u0BA8\u0BCD\u0BA4 \u0BB5\u0BBE\u0BB0\u0BAE\u0BCD \u0B85\u0BB1\u0BBF\u0BB5\u0BBF\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F \u0BAA\u0BC1\u0BA4\u0BBF\u0BAF \u0BB5\u0BB0\u0BCD\u0BA4\u0BCD\u0BA4\u0B95 \u0B92\u0BAA\u0BCD\u0BAA\u0BA8\u0BCD\u0BA4\u0B99\u0BCD\u0B95\u0BB3\u0BBF\u0BA9\u0BCD \u0B9A\u0BBF\u0BB1\u0BCD\u0BB1\u0BB2\u0BC8 \u0BB5\u0BBF\u0BB3\u0BC8\u0BB5\u0BC1\u0B95\u0BB3\u0BC8 \u0B86\u0BAF\u0BCD\u0BB5\u0BBE\u0BB3\u0BB0\u0BCD\u0B95\u0BB3\u0BCD \u0B89\u0BA9\u0BCD\u0BA9\u0BBF\u0BAA\u0BCD\u0BAA\u0BBE\u0B95\u0B95\u0BCD \u0B95\u0BA3\u0BCD\u0B95\u0BBE\u0BA3\u0BBF\u0BA4\u0BCD\u0BA4\u0BC1 \u0BB5\u0BB0\u0BC1\u0B95\u0BBF\u0BA9\u0BCD\u0BB1\u0BA9\u0BB0\u0BCD...</p>",
    coverImageUrl: "https://picsum.photos/seed/a2/800/400",
    authorId: "u4",
    categoryId: "c2",
    tags: ["\u0BAA\u0BCA\u0BB0\u0BC1\u0BB3\u0BBE\u0BA4\u0BBE\u0BB0\u0BAE\u0BCD", "\u0BAA\u0B99\u0BCD\u0B95\u0BC1\u0B9A\u0BCD \u0B9A\u0BA8\u0BCD\u0BA4\u0BC8", "\u0BA8\u0BBF\u0BA4\u0BBF"],
    status: "Published" /* PUBLISHED */,
    publishedAt: "2024-07-22T09:30:00Z",
    views: 18904,
    comments: [
      { id: "com2", authorName: "\u0BAA\u0BCA\u0BB0\u0BC1\u0BB3\u0BBE\u0BA4\u0BBE\u0BB0 \u0BA8\u0BBF\u0BAA\u0BC1\u0BA3\u0BB0\u0BCD", authorAvatarUrl: "https://picsum.photos/seed/com2/50/50", text: "This needs further clarification.", date: "2024-07-23T11:00:00Z", status: "PENDING" },
      { id: "com3", authorName: "\u0BAE\u0BBE\u0BA3\u0BB5\u0BB0\u0BCD", authorAvatarUrl: "https://picsum.photos/seed/com3/50/50", text: "Could you explain the impact on emerging markets?", date: "2024-07-23T11:05:00Z", status: "PENDING" }
    ]
  },
  {
    id: "a5",
    title: "\u0BAE\u0BB0\u0BC1\u0BA4\u0BCD\u0BA4\u0BC1\u0BB5\u0BA4\u0BCD\u0BA4\u0BBF\u0BB2\u0BCD \u0BA4\u0BBF\u0BB0\u0BC1\u0BAA\u0BCD\u0BAA\u0BC1\u0BAE\u0BC1\u0BA9\u0BC8: \u0BA8\u0BCB\u0BAF\u0BBE\u0BB3\u0BBF\u0B95\u0BB3\u0BC1\u0B95\u0BCD\u0B95\u0BC1 \u0B92\u0BB0\u0BC1 \u0BAA\u0BC1\u0BA4\u0BBF\u0BAF \u0BA8\u0BAE\u0BCD\u0BAA\u0BBF\u0B95\u0BCD\u0B95\u0BC8",
    slug: "medical-breakthrough-hope",
    summary: "\u0B92\u0BB0\u0BC1 \u0BAA\u0BC6\u0BB0\u0BBF\u0BAF \u0BA8\u0BCB\u0BAF\u0BCD\u0B95\u0BCD\u0B95\u0BBE\u0BA9 \u0B9A\u0BBF\u0B95\u0BBF\u0B9A\u0BCD\u0B9A\u0BC8 \u0BA8\u0BBF\u0BB2\u0BAA\u0BCD\u0BAA\u0BB0\u0BAA\u0BCD\u0BAA\u0BC8 \u0BAE\u0BBE\u0BB1\u0BCD\u0BB1\u0B95\u0BCD\u0B95\u0BC2\u0B9F\u0BBF\u0BAF \u0B92\u0BB0\u0BC1 \u0B95\u0BC1\u0BB1\u0BBF\u0BAA\u0BCD\u0BAA\u0BBF\u0B9F\u0BA4\u0BCD\u0BA4\u0B95\u0BCD\u0B95 \u0B95\u0BA3\u0BCD\u0B9F\u0BC1\u0BAA\u0BBF\u0B9F\u0BBF\u0BAA\u0BCD\u0BAA\u0BC8 \u0BB5\u0BBF\u0B9E\u0BCD\u0B9E\u0BBE\u0BA9\u0BBF\u0B95\u0BB3\u0BCD \u0B85\u0BB1\u0BBF\u0BB5\u0BBF\u0BA4\u0BCD\u0BA4\u0BC1\u0BB3\u0BCD\u0BB3\u0BA9\u0BB0\u0BCD.",
    content: '<p>"\u0B9C\u0BB0\u0BCD\u0BA9\u0BB2\u0BCD \u0B86\u0B83\u0BAA\u0BCD \u0BAE\u0BC6\u0B9F\u0BBF\u0B9A\u0BBF\u0BA9\u0BCD" \u0B87\u0BB2\u0BCD \u0B87\u0BA9\u0BCD\u0BB1\u0BC1 \u0BB5\u0BC6\u0BB3\u0BBF\u0BAF\u0BBF\u0B9F\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F \u0B92\u0BB0\u0BC1 \u0B85\u0BB1\u0BCD\u0BAA\u0BC1\u0BA4\u0BAE\u0BBE\u0BA9 \u0B86\u0BAF\u0BCD\u0BB5\u0BC1, \u0B86\u0BB0\u0BAE\u0BCD\u0BAA\u0B95\u0BBE\u0BB2 \u0B9A\u0BCB\u0BA4\u0BA9\u0BC8\u0B95\u0BB3\u0BBF\u0BB2\u0BCD \u0B95\u0BC1\u0BB1\u0BBF\u0BAA\u0BCD\u0BAA\u0BBF\u0B9F\u0BA4\u0BCD\u0BA4\u0B95\u0BCD\u0B95 \u0BB5\u0BC6\u0BB1\u0BCD\u0BB1\u0BBF\u0BAF\u0BC8\u0B95\u0BCD \u0B95\u0BBE\u0B9F\u0BCD\u0B9F\u0BBF\u0BAF \u0B92\u0BB0\u0BC1 \u0BAA\u0BC1\u0BA4\u0BBF\u0BAF \u0B9A\u0BBF\u0B95\u0BBF\u0B9A\u0BCD\u0B9A\u0BC8 \u0BAE\u0BC1\u0BB1\u0BC8\u0BAF\u0BC8 \u0BB5\u0BBF\u0BB5\u0BB0\u0BBF\u0B95\u0BCD\u0B95\u0BBF\u0BB1\u0BA4\u0BC1...</p>',
    coverImageUrl: "https://picsum.photos/seed/a5/800/400",
    authorId: "u3",
    categoryId: "c5",
    tags: ["\u0BAE\u0BB0\u0BC1\u0BA4\u0BCD\u0BA4\u0BC1\u0BB5\u0BAE\u0BCD", "\u0B89\u0B9F\u0BB2\u0BCD\u0BA8\u0BB2\u0BAE\u0BCD", "\u0B86\u0BB0\u0BBE\u0BAF\u0BCD\u0B9A\u0BCD\u0B9A\u0BBF"],
    status: "Published" /* PUBLISHED */,
    publishedAt: "2024-07-22T08:00:00Z",
    views: 29489,
    isFeatured: true,
    comments: []
  },
  {
    id: "a7",
    title: "\u0B89\u0BB2\u0B95\u0BB3\u0BBE\u0BB5\u0BBF\u0BAF \u0B95\u0BBE\u0BB2\u0BA8\u0BBF\u0BB2\u0BC8 \u0BAE\u0BBE\u0BA8\u0BBE\u0B9F\u0BC1 \u0BAE\u0BC1\u0B95\u0BCD\u0B95\u0BBF\u0BAF \u0BAE\u0BC1\u0B9F\u0BBF\u0BB5\u0BC1\u0B95\u0BB3\u0BC1\u0B9F\u0BA9\u0BCD \u0BA8\u0BBF\u0BB1\u0BC8\u0BB5\u0B9F\u0BC8\u0B95\u0BBF\u0BB1\u0BA4\u0BC1",
    slug: "global-climate-summit-concludes",
    summary: "\u0B95\u0BBE\u0BB2\u0BA8\u0BBF\u0BB2\u0BC8 \u0BAE\u0BBE\u0BB1\u0BCD\u0BB1\u0BA4\u0BCD\u0BA4\u0BC8 \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BAA\u0BCD\u0BAA\u0BA4\u0BB1\u0BCD\u0B95\u0BBE\u0BA9 \u0BAA\u0BC1\u0BA4\u0BBF\u0BAF \u0B92\u0BAA\u0BCD\u0BAA\u0BA8\u0BCD\u0BA4\u0B99\u0BCD\u0B95\u0BB3\u0BCD \u0BAE\u0BB1\u0BCD\u0BB1\u0BC1\u0BAE\u0BCD \u0BB5\u0BBE\u0B95\u0BCD\u0B95\u0BC1\u0BB1\u0BC1\u0BA4\u0BBF\u0B95\u0BB3\u0BC1\u0B9F\u0BA9\u0BCD \u0B89\u0BB2\u0B95\u0BA4\u0BCD \u0BA4\u0BB2\u0BC8\u0BB5\u0BB0\u0BCD\u0B95\u0BB3\u0BCD \u0BA4\u0B99\u0BCD\u0B95\u0BB3\u0BCD \u0BAA\u0BC7\u0B9A\u0BCD\u0B9A\u0BC1\u0BB5\u0BBE\u0BB0\u0BCD\u0BA4\u0BCD\u0BA4\u0BC8\u0B95\u0BB3\u0BC8 \u0BAE\u0BC1\u0B9F\u0BBF\u0B95\u0BCD\u0B95\u0BBF\u0BA9\u0BCD\u0BB1\u0BA9\u0BB0\u0BCD.",
    content: "<p>\u0BAA\u0BB2 \u0BB5\u0BBE\u0BB0 \u0BA4\u0BC0\u0BB5\u0BBF\u0BB0 \u0BB5\u0BBF\u0BB5\u0BBE\u0BA4\u0B99\u0BCD\u0B95\u0BB3\u0BC1\u0B95\u0BCD\u0B95\u0BC1\u0BAA\u0BCD \u0BAA\u0BBF\u0BB1\u0B95\u0BC1, \u0B89\u0BB2\u0B95\u0BB3\u0BBE\u0BB5\u0BBF\u0BAF \u0B95\u0BBE\u0BB2\u0BA8\u0BBF\u0BB2\u0BC8 \u0BAE\u0BBE\u0BA8\u0BBE\u0B9F\u0BC1 \u0B95\u0BBE\u0BB0\u0BCD\u0BAA\u0BA9\u0BCD \u0B89\u0BAE\u0BBF\u0BB4\u0BCD\u0BB5\u0BC8\u0B95\u0BCD \u0B95\u0BC1\u0BB1\u0BC8\u0BAA\u0BCD\u0BAA\u0BA4\u0BB1\u0BCD\u0B95\u0BC1\u0BAE\u0BCD \u0BAA\u0B9A\u0BC1\u0BAE\u0BC8 \u0B86\u0BB1\u0BCD\u0BB1\u0BB2\u0BCD \u0BAE\u0BC1\u0BAF\u0BB1\u0BCD\u0B9A\u0BBF\u0B95\u0BB3\u0BC1\u0B95\u0BCD\u0B95\u0BC1 \u0BA8\u0BBF\u0BA4\u0BBF\u0BAF\u0BB3\u0BBF\u0BAA\u0BCD\u0BAA\u0BA4\u0BB1\u0BCD\u0B95\u0BC1\u0BAE\u0BCD \u0B92\u0BB0\u0BC1\u0BAE\u0BBF\u0BA4\u0BCD\u0BA4 \u0B95\u0BB0\u0BC1\u0BA4\u0BCD\u0BA4\u0BC1\u0B9F\u0BA9\u0BCD \u0BAE\u0BC1\u0B9F\u0BBF\u0BB5\u0BC1\u0B95\u0BCD\u0B95\u0BC1 \u0BB5\u0BA8\u0BCD\u0BA4\u0BA4\u0BC1...</p>",
    coverImageUrl: "https://picsum.photos/seed/a7/800/400",
    authorId: "u6",
    categoryId: "c6",
    tags: ["\u0B95\u0BBE\u0BB2\u0BA8\u0BBF\u0BB2\u0BC8 \u0BAE\u0BBE\u0BB1\u0BCD\u0BB1\u0BAE\u0BCD", "\u0B89\u0BB2\u0B95\u0BB3\u0BBE\u0BB5\u0BBF\u0BAF \u0BA8\u0BBF\u0B95\u0BB4\u0BCD\u0BB5\u0BC1\u0B95\u0BB3\u0BCD", "\u0B9A\u0BC1\u0BB1\u0BCD\u0BB1\u0BC1\u0B9A\u0BCD\u0B9A\u0BC2\u0BB4\u0BB2\u0BCD"],
    status: "Published" /* PUBLISHED */,
    publishedAt: "2024-07-21T18:00:00Z",
    views: 16432,
    comments: []
  },
  {
    id: "a8",
    title: "\u0BAA\u0BBF\u0BB3\u0BBE\u0B95\u0BCD\u0BAA\u0BB8\u0BCD\u0B9F\u0BB0\u0BCD \u0BA4\u0BBF\u0BB0\u0BC8\u0BAA\u0BCD\u0BAA\u0B9F\u0BAE\u0BCD \u0BAA\u0BBE\u0B95\u0BCD\u0BB8\u0BCD \u0B86\u0BAA\u0BBF\u0BB8\u0BCD \u0B9A\u0BBE\u0BA4\u0BA9\u0BC8\u0B95\u0BB3\u0BC8 \u0BAE\u0BC1\u0BB1\u0BBF\u0BAF\u0B9F\u0BBF\u0B95\u0BCD\u0B95\u0BBF\u0BB1\u0BA4\u0BC1",
    slug: "blockbuster-movie-breaks-records",
    summary: "\u0B9A\u0BAE\u0BC0\u0BAA\u0BA4\u0BCD\u0BA4\u0BBF\u0BAF \u0B9A\u0BC2\u0BAA\u0BCD\u0BAA\u0BB0\u0BCD \u0BB9\u0BC0\u0BB0\u0BCB \u0BA4\u0BBF\u0BB0\u0BC8\u0BAA\u0BCD\u0BAA\u0B9F\u0BAE\u0BCD \u0B85\u0BA4\u0BA9\u0BCD \u0BA4\u0BCA\u0B9F\u0B95\u0BCD\u0B95 \u0BB5\u0BBE\u0BB0 \u0B87\u0BB1\u0BC1\u0BA4\u0BBF\u0BAF\u0BBF\u0BB2\u0BCD \u0B89\u0BB2\u0B95\u0BB3\u0BB5\u0BBF\u0BB2\u0BCD $500 \u0BAE\u0BBF\u0BB2\u0BCD\u0BB2\u0BBF\u0BAF\u0BA9\u0BC8\u0BA4\u0BCD \u0BA4\u0BBE\u0BA3\u0BCD\u0B9F\u0BBF, \u0B8E\u0BB2\u0BCD\u0BB2\u0BBE \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BAA\u0BBE\u0BB0\u0BCD\u0BAA\u0BCD\u0BAA\u0BC1\u0B95\u0BB3\u0BC8\u0BAF\u0BC1\u0BAE\u0BCD \u0BAE\u0BC0\u0BB1\u0BC1\u0B95\u0BBF\u0BB1\u0BA4\u0BC1.",
    content: '<p>\u0BA4\u0BBF\u0BB0\u0BC8\u0BAA\u0BCD\u0BAA\u0B9F\u0BA4\u0BCD \u0BA4\u0BC1\u0BB1\u0BC8\u0BAF\u0BBF\u0BB2\u0BCD \u0B92\u0BB0\u0BC1 \u0B95\u0BC1\u0BB1\u0BBF\u0BAA\u0BCD\u0BAA\u0BBF\u0B9F\u0BA4\u0BCD\u0BA4\u0B95\u0BCD\u0B95 \u0B9A\u0BBE\u0BA4\u0BA9\u0BC8\u0BAF\u0BBE\u0B95, "\u0B95\u0BC7\u0BB2\u0B95\u0BCD\u0BB8\u0BBF \u0B95\u0BBE\u0BB0\u0BCD\u0B9F\u0BBF\u0BAF\u0BA9\u0BCD\u0BB8\u0BCD \u0BB0\u0BBF\u0B9F\u0BCD\u0B9F\u0BB0\u0BCD\u0BA9\u0BCD" \u0BA4\u0BBF\u0BB0\u0BC8\u0BAA\u0BCD\u0BAA\u0B9F\u0BAE\u0BCD \u0BB5\u0BB0\u0BB2\u0BBE\u0BB1\u0BC1 \u0BAA\u0B9F\u0BC8\u0BA4\u0BCD\u0BA4\u0BC1\u0BB3\u0BCD\u0BB3\u0BA4\u0BC1. \u0B85\u0BA4\u0BA9\u0BCD \u0B85\u0BB1\u0BCD\u0BAA\u0BC1\u0BA4\u0BAE\u0BBE\u0BA9 \u0B95\u0BBE\u0B9F\u0BCD\u0B9A\u0BBF\u0B95\u0BB3\u0BCD \u0BAE\u0BB1\u0BCD\u0BB1\u0BC1\u0BAE\u0BCD \u0BB5\u0B9A\u0BC0\u0B95\u0BB0\u0BBF\u0B95\u0BCD\u0B95\u0BC1\u0BAE\u0BCD \u0B95\u0BA4\u0BC8\u0B95\u0BCD\u0B95\u0BB3\u0BA4\u0BCD\u0BA4\u0BC1\u0B9F\u0BA9\u0BCD...</p>',
    coverImageUrl: "https://picsum.photos/seed/a8/800/400",
    authorId: "u7",
    categoryId: "c7",
    tags: ["\u0B9A\u0BBF\u0BA9\u0BBF\u0BAE\u0BBE", "\u0BA4\u0BBF\u0BB0\u0BC8\u0BAA\u0BCD\u0BAA\u0B9F\u0B99\u0BCD\u0B95\u0BB3\u0BCD", "\u0BAA\u0BCA\u0BB4\u0BC1\u0BA4\u0BC1\u0BAA\u0BCB\u0B95\u0BCD\u0B95\u0BC1"],
    status: "Published" /* PUBLISHED */,
    publishedAt: "2024-07-21T15:00:00Z",
    views: 35123,
    isFeatured: true,
    comments: []
  },
  {
    id: "a9",
    title: "\u0BB5\u0BBF\u0BB3\u0BC8\u0BAF\u0BBE\u0B9F\u0BCD\u0B9F\u0BC1\u0BAA\u0BCD \u0BAA\u0BCB\u0B9F\u0BCD\u0B9F\u0BBF\u0BAF\u0BBF\u0BB2\u0BCD \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BAA\u0BBE\u0BB0\u0BBE\u0BA4 \u0BB5\u0BC6\u0BB1\u0BCD\u0BB1\u0BBF: \u0B87\u0BB1\u0BC1\u0BA4\u0BBF \u0BA8\u0BBF\u0BAE\u0BBF\u0B9F \u0B95\u0BCB\u0BB2\u0BCD \u0B86\u0B9F\u0BCD\u0B9F\u0BA4\u0BCD\u0BA4\u0BC8 \u0BAE\u0BC1\u0B9F\u0BBF\u0BB5\u0BC1 \u0B9A\u0BC6\u0BAF\u0BCD\u0BA4\u0BA4\u0BC1",
    slug: "championship-final-last-minute-goal",
    summary: "\u0B92\u0BB0\u0BC1 \u0BAA\u0BB0\u0BAA\u0BB0\u0BAA\u0BCD\u0BAA\u0BBE\u0BA9 \u0B87\u0BB1\u0BC1\u0BA4\u0BBF\u0BAA\u0BCD \u0BAA\u0BCB\u0B9F\u0BCD\u0B9F\u0BBF\u0BAF\u0BBF\u0BB2\u0BCD, \u0B95\u0B9F\u0BC8\u0B9A\u0BBF \u0BA8\u0BBF\u0BAE\u0BBF\u0B9F\u0BA4\u0BCD\u0BA4\u0BBF\u0BB2\u0BCD \u0B85\u0B9F\u0BBF\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F \u0B95\u0BCB\u0BB2\u0BCD \u0B89\u0BB3\u0BCD\u0BB3\u0BC2\u0BB0\u0BCD \u0B85\u0BA3\u0BBF\u0B95\u0BCD\u0B95\u0BC1 \u0B9A\u0BBE\u0BAE\u0BCD\u0BAA\u0BBF\u0BAF\u0BA9\u0BCD\u0BB7\u0BBF\u0BAA\u0BCD \u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BCD\u0BA4\u0BC8 \u0BB5\u0BC6\u0BA9\u0BCD\u0BB1\u0BC1 \u0BA4\u0BA8\u0BCD\u0BA4\u0BA4\u0BC1.",
    content: "<p>\u0B86\u0BAF\u0BBF\u0BB0\u0B95\u0BCD\u0B95\u0BA3\u0B95\u0BCD\u0B95\u0BBE\u0BA9 \u0BB0\u0B9A\u0BBF\u0B95\u0BB0\u0BCD\u0B95\u0BB3\u0BCD \u0BAE\u0BC1\u0BA9\u0BCD\u0BA9\u0BBF\u0BB2\u0BC8\u0BAF\u0BBF\u0BB2\u0BCD, \u0B95\u0BBE\u0BB2\u0BCD\u0BAA\u0BA8\u0BCD\u0BA4\u0BC1 \u0B9A\u0BBE\u0BAE\u0BCD\u0BAA\u0BBF\u0BAF\u0BA9\u0BCD\u0BB7\u0BBF\u0BAA\u0BCD \u0B87\u0BB1\u0BC1\u0BA4\u0BBF\u0BAA\u0BCD \u0BAA\u0BCB\u0B9F\u0BCD\u0B9F\u0BBF \u0B92\u0BB0\u0BC1 \u0BAE\u0BB1\u0B95\u0BCD\u0B95 \u0BAE\u0BC1\u0B9F\u0BBF\u0BAF\u0BBE\u0BA4 \u0BA4\u0BB0\u0BC1\u0BA3\u0BA4\u0BCD\u0BA4\u0BC8\u0B95\u0BCD \u0B95\u0BA3\u0BCD\u0B9F\u0BA4\u0BC1. \u0B86\u0B9F\u0BCD\u0B9F\u0BAE\u0BCD \u0B9A\u0BAE\u0BA8\u0BBF\u0BB2\u0BC8\u0BAF\u0BBF\u0BB2\u0BCD \u0B87\u0BB0\u0BC1\u0BA8\u0BCD\u0BA4\u0BAA\u0BCB\u0BA4\u0BC1, \u0B92\u0BB0\u0BC1 \u0B85\u0BB1\u0BCD\u0BAA\u0BC1\u0BA4\u0BAE\u0BBE\u0BA9 \u0B95\u0BCB\u0BB2\u0BCD...</p>",
    coverImageUrl: "https://picsum.photos/seed/a9/800/400",
    authorId: "u4",
    categoryId: "c4",
    tags: ["\u0B95\u0BBE\u0BB2\u0BCD\u0BAA\u0BA8\u0BCD\u0BA4\u0BC1", "\u0BB5\u0BBF\u0BB3\u0BC8\u0BAF\u0BBE\u0B9F\u0BCD\u0B9F\u0BC1", "\u0B9A\u0BBE\u0BAE\u0BCD\u0BAA\u0BBF\u0BAF\u0BA9\u0BCD\u0BB7\u0BBF\u0BAA\u0BCD"],
    status: "Published" /* PUBLISHED */,
    publishedAt: "2024-07-21T12:00:00Z",
    views: 21550,
    comments: []
  },
  {
    id: "a10",
    title: "\u0B9A\u0BC6\u0BB5\u0BCD\u0BB5\u0BBE\u0BAF\u0BCD \u0B95\u0BBF\u0BB0\u0B95\u0BA4\u0BCD\u0BA4\u0BBF\u0BB2\u0BCD \u0BA8\u0BC0\u0BB0\u0BCD \u0B87\u0BB0\u0BC1\u0BAA\u0BCD\u0BAA\u0BA4\u0BB1\u0BCD\u0B95\u0BBE\u0BA9 \u0BAA\u0BC1\u0BA4\u0BBF\u0BAF \u0B86\u0BA4\u0BBE\u0BB0\u0B99\u0BCD\u0B95\u0BB3\u0BC8 \u0BA8\u0BBE\u0B9A\u0BBE \u0B95\u0BA3\u0BCD\u0B9F\u0BC1\u0BAA\u0BBF\u0B9F\u0BBF\u0BA4\u0BCD\u0BA4\u0BA4\u0BC1",
    slug: "nasa-finds-new-evidence-of-water-on-mars",
    summary: "\u0B9A\u0BC6\u0BB5\u0BCD\u0BB5\u0BBE\u0BAF\u0BCD \u0B95\u0BBF\u0BB0\u0B95\u0BA4\u0BCD\u0BA4\u0BBF\u0BA9\u0BCD \u0BAE\u0BC7\u0BB1\u0BCD\u0BAA\u0BB0\u0BAA\u0BCD\u0BAA\u0BBF\u0BB1\u0BCD\u0B95\u0BC1 \u0B85\u0B9F\u0BBF\u0BAF\u0BBF\u0BB2\u0BCD \u0B89\u0BB1\u0BC8\u0BA8\u0BCD\u0BA4 \u0BA8\u0BC0\u0BB0\u0BCD \u0B8F\u0BB0\u0BBF\u0B95\u0BB3\u0BCD \u0B87\u0BB0\u0BC1\u0BAA\u0BCD\u0BAA\u0BA4\u0BB1\u0BCD\u0B95\u0BBE\u0BA9 \u0BB5\u0BB2\u0BC1\u0BB5\u0BBE\u0BA9 \u0B86\u0BA4\u0BBE\u0BB0\u0B99\u0BCD\u0B95\u0BB3\u0BC8 \u0BA8\u0BBE\u0B9A\u0BBE\u0BB5\u0BBF\u0BA9\u0BCD \u0BB0\u0BCB\u0BB5\u0BB0\u0BCD \u0B85\u0BA9\u0BC1\u0BAA\u0BCD\u0BAA\u0BBF\u0BAF\u0BC1\u0BB3\u0BCD\u0BB3\u0BA4\u0BC1.",
    content: "<p>\u0BB5\u0BBF\u0BA3\u0BCD\u0BB5\u0BC6\u0BB3\u0BBF \u0B86\u0BB0\u0BBE\u0BAF\u0BCD\u0B9A\u0BCD\u0B9A\u0BBF\u0BAF\u0BBF\u0BB2\u0BCD \u0B92\u0BB0\u0BC1 \u0BAE\u0BC1\u0B95\u0BCD\u0B95\u0BBF\u0BAF \u0BAE\u0BC8\u0BB2\u0BCD\u0B95\u0BB2\u0BCD\u0BB2\u0BBE\u0B95, \u0B9A\u0BC6\u0BB5\u0BCD\u0BB5\u0BBE\u0BAF\u0BCD \u0B95\u0BBF\u0BB0\u0B95\u0BA4\u0BCD\u0BA4\u0BBF\u0BB2\u0BCD \u0B89\u0BAF\u0BBF\u0BB0\u0BCD\u0B95\u0BB3\u0BCD \u0BB5\u0BBE\u0BB4\u0BCD\u0BB5\u0BA4\u0BB1\u0BCD\u0B95\u0BBE\u0BA9 \u0B9A\u0BBE\u0BA4\u0BCD\u0BA4\u0BBF\u0BAF\u0B95\u0BCD\u0B95\u0BC2\u0BB1\u0BC1\u0B95\u0BB3\u0BCD \u0B95\u0BC1\u0BB1\u0BBF\u0BA4\u0BCD\u0BA4 \u0BAA\u0BC1\u0BA4\u0BBF\u0BAF \u0BA8\u0BAE\u0BCD\u0BAA\u0BBF\u0B95\u0BCD\u0B95\u0BC8\u0BAF\u0BC8 \u0BA8\u0BBE\u0B9A\u0BBE\u0BB5\u0BBF\u0BA9\u0BCD \u0B95\u0BA3\u0BCD\u0B9F\u0BC1\u0BAA\u0BBF\u0B9F\u0BBF\u0BAA\u0BCD\u0BAA\u0BC1\u0B95\u0BB3\u0BCD \u0BA4\u0BC2\u0BA3\u0BCD\u0B9F\u0BBF\u0BAF\u0BC1\u0BB3\u0BCD\u0BB3\u0BA9...</p>",
    coverImageUrl: "https://picsum.photos/seed/a10/800/400",
    authorId: "u6",
    categoryId: "c9",
    tags: ["\u0BB5\u0BBF\u0BA3\u0BCD\u0BB5\u0BC6\u0BB3\u0BBF", "\u0BA8\u0BBE\u0B9A\u0BBE", "\u0B85\u0BB1\u0BBF\u0BB5\u0BBF\u0BAF\u0BB2\u0BCD"],
    status: "Published" /* PUBLISHED */,
    publishedAt: "2024-07-20T11:00:00Z",
    views: 19876,
    comments: []
  },
  {
    id: "a11",
    title: "\u0B86\u0BB0\u0BCB\u0B95\u0BCD\u0B95\u0BBF\u0BAF\u0BAE\u0BBE\u0BA9 \u0BB5\u0BBE\u0BB4\u0BCD\u0B95\u0BCD\u0B95\u0BC8 \u0BAE\u0BC1\u0BB1\u0BC8\u0B95\u0BCD\u0B95\u0BBE\u0BA9 5 \u0B8E\u0BB3\u0BBF\u0BAF \u0B95\u0BC1\u0BB1\u0BBF\u0BAA\u0BCD\u0BAA\u0BC1\u0B95\u0BB3\u0BCD",
    slug: "5-tips-for-healthy-lifestyle",
    summary: "\u0B89\u0B99\u0BCD\u0B95\u0BB3\u0BCD \u0B85\u0BA9\u0BCD\u0BB1\u0BBE\u0B9F \u0BB5\u0BBE\u0BB4\u0BCD\u0B95\u0BCD\u0B95\u0BC8\u0BAF\u0BBF\u0BB2\u0BCD \u0B9A\u0BBF\u0BB1\u0BBF\u0BAF \u0BAE\u0BBE\u0BB1\u0BCD\u0BB1\u0B99\u0BCD\u0B95\u0BB3\u0BC8\u0B9A\u0BCD \u0B9A\u0BC6\u0BAF\u0BCD\u0BB5\u0BA4\u0BA9\u0BCD \u0BAE\u0BC2\u0BB2\u0BAE\u0BCD \u0B89\u0B99\u0BCD\u0B95\u0BB3\u0BCD \u0B92\u0B9F\u0BCD\u0B9F\u0BC1\u0BAE\u0BCA\u0BA4\u0BCD\u0BA4 \u0B86\u0BB0\u0BCB\u0B95\u0BCD\u0B95\u0BBF\u0BAF\u0BA4\u0BCD\u0BA4\u0BC8\u0BAF\u0BC1\u0BAE\u0BCD \u0BA8\u0BB2\u0BCD\u0BB5\u0BBE\u0BB4\u0BCD\u0BB5\u0BC8\u0BAF\u0BC1\u0BAE\u0BCD \u0BAE\u0BC7\u0BAE\u0BCD\u0BAA\u0B9F\u0BC1\u0BA4\u0BCD\u0BA4\u0BB2\u0BBE\u0BAE\u0BCD.",
    content: "<p>\u0B9A\u0BAE\u0B9A\u0BCD\u0B9A\u0BC0\u0BB0\u0BCD \u0B89\u0BA3\u0BB5\u0BC1, \u0BB5\u0BB4\u0B95\u0BCD\u0B95\u0BAE\u0BBE\u0BA9 \u0B89\u0B9F\u0BB1\u0BCD\u0BAA\u0BAF\u0BBF\u0BB1\u0BCD\u0B9A\u0BBF \u0BAE\u0BB1\u0BCD\u0BB1\u0BC1\u0BAE\u0BCD \u0BAA\u0BCB\u0BA4\u0BC1\u0BAE\u0BBE\u0BA9 \u0BA4\u0BC2\u0B95\u0BCD\u0B95\u0BAE\u0BCD \u0B86\u0B95\u0BBF\u0BAF\u0BB5\u0BC8 \u0B86\u0BB0\u0BCB\u0B95\u0BCD\u0B95\u0BBF\u0BAF\u0BAE\u0BBE\u0BA9 \u0BB5\u0BBE\u0BB4\u0BCD\u0B95\u0BCD\u0B95\u0BC8\u0B95\u0BCD\u0B95\u0BC1 \u0B85\u0BB5\u0B9A\u0BBF\u0BAF\u0BAE\u0BCD. \u0B87\u0BA8\u0BCD\u0BA4 \u0B95\u0B9F\u0BCD\u0B9F\u0BC1\u0BB0\u0BC8\u0BAF\u0BBF\u0BB2\u0BCD, \u0BA8\u0BC0\u0B99\u0BCD\u0B95\u0BB3\u0BCD \u0BAA\u0BBF\u0BA9\u0BCD\u0BAA\u0BB1\u0BCD\u0BB1\u0B95\u0BCD\u0B95\u0BC2\u0B9F\u0BBF\u0BAF \u0B8E\u0BB3\u0BBF\u0BAF \u0BAE\u0BB1\u0BCD\u0BB1\u0BC1\u0BAE\u0BCD \u0BAA\u0BAF\u0BA9\u0BC1\u0BB3\u0BCD\u0BB3 \u0B95\u0BC1\u0BB1\u0BBF\u0BAA\u0BCD\u0BAA\u0BC1\u0B95\u0BB3\u0BCD \u0B95\u0BCA\u0B9F\u0BC1\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BC1\u0BB3\u0BCD\u0BB3\u0BA9...</p>",
    coverImageUrl: "https://picsum.photos/seed/a11/800/400",
    authorId: "u3",
    categoryId: "c8",
    tags: ["\u0BB5\u0BBE\u0BB4\u0BCD\u0B95\u0BCD\u0B95\u0BC8 \u0BAE\u0BC1\u0BB1\u0BC8", "\u0B86\u0BB0\u0BCB\u0B95\u0BCD\u0B95\u0BBF\u0BAF\u0BAE\u0BCD", "\u0B95\u0BC1\u0BB1\u0BBF\u0BAA\u0BCD\u0BAA\u0BC1\u0B95\u0BB3\u0BCD"],
    status: "Published" /* PUBLISHED */,
    publishedAt: "2024-07-20T09:00:00Z",
    views: 45001,
    isFeatured: true,
    comments: []
  },
  {
    id: "a12",
    title: "\u0BAA\u0BC1\u0BA4\u0BBF\u0BAF \u0BB8\u0BCD\u0BAE\u0BBE\u0BB0\u0BCD\u0B9F\u0BCD\u0BAA\u0BCB\u0BA9\u0BCD \u0BB5\u0BC6\u0BB3\u0BBF\u0BAF\u0BC0\u0B9F\u0BC1: \u0BA4\u0BCA\u0BB4\u0BBF\u0BB2\u0BCD\u0BA8\u0BC1\u0B9F\u0BCD\u0BAA \u0B89\u0BB2\u0B95\u0BBF\u0BB2\u0BCD \u0B92\u0BB0\u0BC1 \u0BAA\u0BC1\u0BA4\u0BBF\u0BAF \u0BAA\u0BC1\u0BB0\u0B9F\u0BCD\u0B9A\u0BBF",
    slug: "new-smartphone-revolution",
    summary: "\u0BAE\u0BC1\u0BA9\u0BCD\u0BA9\u0BA3\u0BBF \u0BA4\u0BCA\u0BB4\u0BBF\u0BB2\u0BCD\u0BA8\u0BC1\u0B9F\u0BCD\u0BAA \u0BA8\u0BBF\u0BB1\u0BC1\u0BB5\u0BA9\u0BAE\u0BCD \u0BA4\u0BA9\u0BA4\u0BC1 \u0BAA\u0BC1\u0BA4\u0BBF\u0BAF \u0BAE\u0BC1\u0BA4\u0BA9\u0BCD\u0BAE\u0BC8 \u0BB8\u0BCD\u0BAE\u0BBE\u0BB0\u0BCD\u0B9F\u0BCD\u0BAA\u0BCB\u0BA9\u0BC8 \u0BB5\u0BC6\u0BB3\u0BBF\u0BAF\u0BBF\u0B9F\u0BCD\u0B9F\u0BC1\u0BB3\u0BCD\u0BB3\u0BA4\u0BC1, \u0B87\u0BA4\u0BC1 \u0BAE\u0BC7\u0BAE\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F \u0B95\u0BC7\u0BAE\u0BB0\u0BBE \u0BAE\u0BB1\u0BCD\u0BB1\u0BC1\u0BAE\u0BCD \u0BA8\u0BC0\u0BA3\u0BCD\u0B9F \u0BAA\u0BC7\u0B9F\u0BCD\u0B9F\u0BB0\u0BBF \u0B86\u0BAF\u0BC1\u0BB3\u0BC8\u0B95\u0BCD \u0B95\u0BCA\u0BA3\u0BCD\u0B9F\u0BC1\u0BB3\u0BCD\u0BB3\u0BA4\u0BC1.",
    content: '<p>\u0BA4\u0BCA\u0BB4\u0BBF\u0BB2\u0BCD\u0BA8\u0BC1\u0B9F\u0BCD\u0BAA \u0B86\u0BB0\u0BCD\u0BB5\u0BB2\u0BB0\u0BCD\u0B95\u0BB3\u0BCD \u0B86\u0BB5\u0BB2\u0BC1\u0B9F\u0BA9\u0BCD \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BAA\u0BBE\u0BB0\u0BCD\u0BA4\u0BCD\u0BA4 \u0BAA\u0BC1\u0BA4\u0BBF\u0BAF "\u0B95\u0BC7\u0BB2\u0B95\u0BCD\u0BB8\u0BBF \u0B8E\u0B95\u0BCD\u0BB8\u0BCD" \u0BB8\u0BCD\u0BAE\u0BBE\u0BB0\u0BCD\u0B9F\u0BCD\u0BAA\u0BCB\u0BA9\u0BCD \u0B87\u0BA9\u0BCD\u0BB1\u0BC1 \u0BB5\u0BC6\u0BB3\u0BBF\u0BAF\u0BBF\u0B9F\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F\u0BA4\u0BC1. \u0B87\u0BA4\u0BA9\u0BCD \u0B85\u0BAE\u0BCD\u0B9A\u0B99\u0BCD\u0B95\u0BB3\u0BCD \u0BAE\u0BB1\u0BCD\u0BB1\u0BC1\u0BAE\u0BCD \u0BB5\u0BBF\u0BB2\u0BC8 \u0BB5\u0BBF\u0BB5\u0BB0\u0B99\u0BCD\u0B95\u0BB3\u0BC8 \u0B87\u0B99\u0BCD\u0B95\u0BC7 \u0B95\u0BBE\u0BA3\u0BB2\u0BBE\u0BAE\u0BCD...</p>',
    coverImageUrl: "https://picsum.photos/seed/a12/800/400",
    authorId: "u7",
    categoryId: "c1",
    tags: ["\u0BB8\u0BCD\u0BAE\u0BBE\u0BB0\u0BCD\u0B9F\u0BCD\u0BAA\u0BCB\u0BA9\u0BCD", "\u0BA4\u0BCA\u0BB4\u0BBF\u0BB2\u0BCD\u0BA8\u0BC1\u0B9F\u0BCD\u0BAA\u0BAE\u0BCD", "\u0BB5\u0BC6\u0BB3\u0BBF\u0BAF\u0BC0\u0B9F\u0BC1"],
    status: "Published" /* PUBLISHED */,
    publishedAt: "2024-07-19T16:00:00Z",
    views: 12345,
    comments: []
  },
  {
    id: "a13",
    title: "\u0BA4\u0BC7\u0BB0\u0BCD\u0BA4\u0BB2\u0BCD \u0B95\u0BB3\u0BAE\u0BCD \u0B9A\u0BC2\u0B9F\u0BC1\u0BAA\u0BBF\u0B9F\u0BBF\u0B95\u0BCD\u0B95\u0BBF\u0BB1\u0BA4\u0BC1: \u0BAE\u0BC1\u0B95\u0BCD\u0B95\u0BBF\u0BAF \u0B95\u0B9F\u0BCD\u0B9A\u0BBF\u0B95\u0BB3\u0BCD \u0BAA\u0BBF\u0BB0\u0B9A\u0BCD\u0B9A\u0BBE\u0BB0\u0BA4\u0BCD\u0BA4\u0BC8 \u0BA4\u0BC0\u0BB5\u0BBF\u0BB0\u0BAA\u0BCD\u0BAA\u0B9F\u0BC1\u0BA4\u0BCD\u0BA4\u0BC1\u0B95\u0BBF\u0BA9\u0BCD\u0BB1\u0BA9",
    slug: "election-campaign-intensifies",
    summary: "\u0BB5\u0BB0\u0BB5\u0BBF\u0BB0\u0BC1\u0B95\u0BCD\u0B95\u0BC1\u0BAE\u0BCD \u0BA4\u0BC7\u0BB0\u0BCD\u0BA4\u0BB2\u0BC8 \u0BAE\u0BC1\u0BA9\u0BCD\u0BA9\u0BBF\u0B9F\u0BCD\u0B9F\u0BC1, \u0B85\u0BB0\u0B9A\u0BBF\u0BAF\u0BB2\u0BCD \u0B95\u0B9F\u0BCD\u0B9A\u0BBF\u0B95\u0BB3\u0BCD \u0BA4\u0B99\u0BCD\u0B95\u0BB3\u0BCD \u0BA4\u0BC7\u0BB0\u0BCD\u0BA4\u0BB2\u0BCD \u0B85\u0BB1\u0BBF\u0B95\u0BCD\u0B95\u0BC8\u0B95\u0BB3\u0BC8 \u0BB5\u0BC6\u0BB3\u0BBF\u0BAF\u0BBF\u0B9F\u0BCD\u0B9F\u0BC1, \u0BA8\u0BBE\u0B9F\u0BC1 \u0BA4\u0BB4\u0BC1\u0BB5\u0BBF\u0BAF \u0BAA\u0BBF\u0BB0\u0B9A\u0BCD\u0B9A\u0BBE\u0BB0\u0BA4\u0BCD\u0BA4\u0BBF\u0BB2\u0BCD \u0B88\u0B9F\u0BC1\u0BAA\u0B9F\u0BCD\u0B9F\u0BC1\u0BB3\u0BCD\u0BB3\u0BA9.",
    content: "<p>\u0BB5\u0BBE\u0B95\u0BCD\u0B95\u0BC1\u0BAA\u0BCD\u0BAA\u0BA4\u0BBF\u0BB5\u0BC1 \u0BA8\u0BC6\u0BB0\u0BC1\u0B99\u0BCD\u0B95\u0BBF \u0BB5\u0BB0\u0BC1\u0BB5\u0BA4\u0BBE\u0BB2\u0BCD, \u0B85\u0BB0\u0B9A\u0BBF\u0BAF\u0BB2\u0BCD \u0B95\u0BB3\u0BAE\u0BCD \u0BAA\u0BB0\u0BAA\u0BB0\u0BAA\u0BCD\u0BAA\u0BBE\u0B95 \u0B95\u0BBE\u0BA3\u0BAA\u0BCD\u0BAA\u0B9F\u0BC1\u0B95\u0BBF\u0BB1\u0BA4\u0BC1. \u0BA4\u0BB2\u0BC8\u0BB5\u0BB0\u0BCD\u0B95\u0BB3\u0BCD \u0BAA\u0BCA\u0BA4\u0BC1\u0B95\u0BCD\u0B95\u0BC2\u0B9F\u0BCD\u0B9F\u0B99\u0BCD\u0B95\u0BB3\u0BCD \u0BAE\u0BB1\u0BCD\u0BB1\u0BC1\u0BAE\u0BCD \u0BAA\u0BC7\u0BB0\u0BA3\u0BBF\u0B95\u0BB3\u0BBF\u0BB2\u0BCD \u0B88\u0B9F\u0BC1\u0BAA\u0B9F\u0BCD\u0B9F\u0BC1 \u0BB5\u0BBE\u0B95\u0BCD\u0B95\u0BBE\u0BB3\u0BB0\u0BCD\u0B95\u0BB3\u0BC8\u0B95\u0BCD \u0B95\u0BB5\u0BB0 \u0BAE\u0BC1\u0BAF\u0BB1\u0BCD\u0B9A\u0BBF\u0B95\u0BCD\u0B95\u0BBF\u0BA9\u0BCD\u0BB1\u0BA9\u0BB0\u0BCD...</p>",
    coverImageUrl: "https://picsum.photos/seed/a13/800/400",
    authorId: "u4",
    categoryId: "c3",
    tags: ["\u0B85\u0BB0\u0B9A\u0BBF\u0BAF\u0BB2\u0BCD", "\u0BA4\u0BC7\u0BB0\u0BCD\u0BA4\u0BB2\u0BCD", "\u0B9A\u0BC6\u0BAF\u0BCD\u0BA4\u0BBF\u0B95\u0BB3\u0BCD"],
    status: "Published" /* PUBLISHED */,
    publishedAt: "2024-07-19T11:00:00Z",
    views: 9876,
    comments: []
  },
  {
    id: "a14",
    title: "\u0BB8\u0BCD\u0B9F\u0BBE\u0BB0\u0BCD\u0B9F\u0BCD\u0B85\u0BAA\u0BCD \u0BA8\u0BBF\u0BB1\u0BC1\u0BB5\u0BA9\u0B99\u0BCD\u0B95\u0BB3\u0BC1\u0B95\u0BCD\u0B95\u0BC1 \u0BAA\u0BC1\u0BA4\u0BBF\u0BAF \u0BAE\u0BC1\u0BA4\u0BB2\u0BC0\u0B9F\u0BC1\u0B95\u0BB3\u0BCD: \u0BA4\u0BCA\u0BB4\u0BBF\u0BB2\u0BCD\u0BAE\u0BC1\u0BA9\u0BC8\u0BB5\u0BCB\u0BB0\u0BC1\u0B95\u0BCD\u0B95\u0BC1 \u0B8A\u0B95\u0BCD\u0B95\u0BAE\u0BCD",
    slug: "startup-funding-boost",
    summary: "\u0B87\u0BA8\u0BCD\u0BA4\u0BBF\u0BAF \u0BB8\u0BCD\u0B9F\u0BBE\u0BB0\u0BCD\u0B9F\u0BCD\u0B85\u0BAA\u0BCD \u0B9A\u0BC2\u0BB4\u0BB2\u0BCD \u0B92\u0BB0\u0BC1 \u0BAA\u0BC6\u0BB0\u0BBF\u0BAF \u0B8A\u0B95\u0BCD\u0B95\u0BA4\u0BCD\u0BA4\u0BC8\u0BAA\u0BCD \u0BAA\u0BC6\u0BB1\u0BC1\u0B95\u0BBF\u0BB1\u0BA4\u0BC1, \u0B8F\u0BA9\u0BC6\u0BA9\u0BBF\u0BB2\u0BCD \u0BA4\u0BC1\u0BA3\u0BBF\u0B95\u0BB0 \u0BAE\u0BC2\u0BB2\u0BA4\u0BA9 \u0BA8\u0BBF\u0BB1\u0BC1\u0BB5\u0BA9\u0B99\u0BCD\u0B95\u0BB3\u0BCD \u0BAA\u0BC1\u0BA4\u0BC1\u0BAE\u0BC8\u0BAF\u0BBE\u0BA9 \u0BAF\u0BCB\u0B9A\u0BA9\u0BC8\u0B95\u0BB3\u0BBF\u0BB2\u0BCD \u0BAE\u0BBF\u0BB2\u0BCD\u0BB2\u0BBF\u0BAF\u0BA9\u0BCD \u0B95\u0BA3\u0B95\u0BCD\u0B95\u0BBE\u0BA9 \u0B9F\u0BBE\u0BB2\u0BB0\u0BCD\u0B95\u0BB3\u0BC8 \u0BAE\u0BC1\u0BA4\u0BB2\u0BC0\u0B9F\u0BC1 \u0B9A\u0BC6\u0BAF\u0BCD\u0B95\u0BBF\u0BA9\u0BCD\u0BB1\u0BA9.",
    content: "<p>\u0BA4\u0BCA\u0BB4\u0BBF\u0BB2\u0BCD\u0BA8\u0BC1\u0B9F\u0BCD\u0BAA\u0BAE\u0BCD, \u0B9A\u0BC1\u0B95\u0BBE\u0BA4\u0BBE\u0BB0\u0BAE\u0BCD \u0BAE\u0BB1\u0BCD\u0BB1\u0BC1\u0BAE\u0BCD \u0BA8\u0BBF\u0BA4\u0BBF\u0B9A\u0BCD \u0B9A\u0BC7\u0BB5\u0BC8\u0BA4\u0BCD \u0BA4\u0BC1\u0BB1\u0BC8\u0B95\u0BB3\u0BBF\u0BB2\u0BCD \u0B89\u0BB3\u0BCD\u0BB3 \u0BAA\u0BB2 \u0B87\u0BB3\u0BAE\u0BCD \u0BA8\u0BBF\u0BB1\u0BC1\u0BB5\u0BA9\u0B99\u0BCD\u0B95\u0BB3\u0BCD \u0B95\u0BC1\u0BB1\u0BBF\u0BAA\u0BCD\u0BAA\u0BBF\u0B9F\u0BA4\u0BCD\u0BA4\u0B95\u0BCD\u0B95 \u0BA8\u0BBF\u0BA4\u0BBF\u0BAF\u0BC1\u0BA4\u0BB5\u0BBF\u0BAF\u0BC8\u0BAA\u0BCD \u0BAA\u0BC6\u0BB1\u0BCD\u0BB1\u0BC1\u0BB3\u0BCD\u0BB3\u0BA9. \u0B87\u0BA4\u0BC1 \u0BA8\u0BBE\u0B9F\u0BCD\u0B9F\u0BBF\u0BA9\u0BCD \u0BAA\u0BCA\u0BB0\u0BC1\u0BB3\u0BBE\u0BA4\u0BBE\u0BB0 \u0BB5\u0BB3\u0BB0\u0BCD\u0B9A\u0BCD\u0B9A\u0BBF\u0B95\u0BCD\u0B95\u0BC1 \u0BAA\u0B99\u0BCD\u0B95\u0BB3\u0BBF\u0B95\u0BCD\u0B95\u0BC1\u0BAE\u0BCD \u0B8E\u0BA9 \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BC1\u0B95\u0BBF\u0BB1\u0BA4\u0BC1...</p>",
    coverImageUrl: "https://picsum.photos/seed/a14/800/400",
    authorId: "u6",
    categoryId: "c2",
    tags: ["\u0BB8\u0BCD\u0B9F\u0BBE\u0BB0\u0BCD\u0B9F\u0BCD\u0B85\u0BAA\u0BCD", "\u0BB5\u0BA3\u0BBF\u0B95\u0BAE\u0BCD", "\u0BAE\u0BC1\u0BA4\u0BB2\u0BC0\u0B9F\u0BC1"],
    status: "Published" /* PUBLISHED */,
    publishedAt: "2024-07-18T14:00:00Z",
    views: 7500,
    comments: []
  },
  // Advertisement Articles
  {
    id: "ad1",
    title: "\u0B89\u0B99\u0BCD\u0B95\u0BB3\u0BCD \u0B95\u0BA9\u0BB5\u0BC1 \u0B87\u0BB2\u0BCD\u0BB2\u0BAE\u0BCD: \u0BAA\u0BC1\u0BA4\u0BBF\u0BAF \u0B85\u0B9F\u0BC1\u0B95\u0BCD\u0B95\u0BC1\u0BAE\u0BBE\u0B9F\u0BBF \u0B95\u0BC1\u0B9F\u0BBF\u0BAF\u0BBF\u0BB0\u0BC1\u0BAA\u0BCD\u0BAA\u0BC1\u0B95\u0BB3\u0BCD \u0BB5\u0BBF\u0BB1\u0BCD\u0BAA\u0BA9\u0BC8\u0B95\u0BCD\u0B95\u0BC1",
    slug: "dream-home-apartments-sale",
    summary: "\u0B9A\u0BC6\u0BA9\u0BCD\u0BA9\u0BC8\u0BAF\u0BBF\u0BA9\u0BCD \u0BAE\u0BC8\u0BAF\u0BA4\u0BCD\u0BA4\u0BBF\u0BB2\u0BCD \u0BA8\u0BB5\u0BC0\u0BA9 \u0BB5\u0B9A\u0BA4\u0BBF\u0B95\u0BB3\u0BC1\u0B9F\u0BA9\u0BCD \u0B95\u0BC2\u0B9F\u0BBF\u0BAF \u0B9A\u0BCA\u0B95\u0BC1\u0B9A\u0BC1 \u0BB5\u0BC0\u0B9F\u0BC1\u0B95\u0BB3\u0BCD. \u0B87\u0BA9\u0BCD\u0BB1\u0BC7 \u0BAE\u0BC1\u0BA9\u0BCD\u0BAA\u0BA4\u0BBF\u0BB5\u0BC1 \u0B9A\u0BC6\u0BAF\u0BCD\u0BAF\u0BC1\u0B99\u0BCD\u0B95\u0BB3\u0BCD!",
    content: "<p>\u0B89\u0B99\u0BCD\u0B95\u0BB3\u0BCD \u0BB5\u0BBE\u0BB4\u0BCD\u0B95\u0BCD\u0B95\u0BC8 \u0BAE\u0BC1\u0BB1\u0BC8\u0BAF\u0BC8 \u0BAE\u0BC7\u0BAE\u0BCD\u0BAA\u0B9F\u0BC1\u0BA4\u0BCD\u0BA4\u0BC1\u0BAE\u0BCD \u0BB5\u0B95\u0BC8\u0BAF\u0BBF\u0BB2\u0BCD \u0BB5\u0B9F\u0BBF\u0BB5\u0BAE\u0BC8\u0B95\u0BCD\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BCD\u0B9F \u0B8E\u0B99\u0BCD\u0B95\u0BB3\u0BBF\u0BA9\u0BCD \u0BAA\u0BC1\u0BA4\u0BBF\u0BAF \u0BA4\u0BBF\u0B9F\u0BCD\u0B9F\u0BA4\u0BCD\u0BA4\u0BC8 \u0B85\u0BB1\u0BBF\u0BAE\u0BC1\u0B95\u0BAA\u0BCD\u0BAA\u0B9F\u0BC1\u0BA4\u0BCD\u0BA4\u0BC1\u0B95\u0BBF\u0BB1\u0BCB\u0BAE\u0BCD. \u0BA8\u0BC0\u0B9A\u0BCD\u0B9A\u0BB2\u0BCD \u0B95\u0BC1\u0BB3\u0BAE\u0BCD, \u0B89\u0B9F\u0BB1\u0BCD\u0BAA\u0BAF\u0BBF\u0BB1\u0BCD\u0B9A\u0BBF \u0B95\u0BC2\u0B9F\u0BAE\u0BCD \u0BAE\u0BB1\u0BCD\u0BB1\u0BC1\u0BAE\u0BCD 24/7 \u0BAA\u0BBE\u0BA4\u0BC1\u0B95\u0BBE\u0BAA\u0BCD\u0BAA\u0BC1 \u0BAA\u0BCB\u0BA9\u0BCD\u0BB1 \u0BB5\u0B9A\u0BA4\u0BBF\u0B95\u0BB3\u0BC1\u0B9F\u0BA9\u0BCD...</p>",
    coverImageUrl: "https://picsum.photos/seed/ad1/800/400",
    authorId: "u1",
    categoryId: "c8",
    tags: ["\u0BB0\u0BBF\u0BAF\u0BB2\u0BCD \u0B8E\u0BB8\u0BCD\u0B9F\u0BC7\u0B9F\u0BCD", "\u0BAE\u0BC1\u0BA4\u0BB2\u0BC0\u0B9F\u0BC1", "\u0B9A\u0BC6\u0BA9\u0BCD\u0BA9\u0BC8"],
    status: "Published" /* PUBLISHED */,
    publishedAt: "2024-07-22T11:00:00Z",
    views: 5e3,
    comments: [],
    isAdvertisement: true
  },
  {
    id: "ad2",
    title: "\u0BAA\u0BC1\u0BA4\u0BBF\u0BAF \u0B9F\u0BC6\u0B95\u0BCD\u0BA9\u0BCB \u0BAE\u0BCA\u0BAA\u0BC8\u0BB2\u0BCD: \u0B85\u0B9A\u0BA4\u0BCD\u0BA4\u0BB2\u0BBE\u0BA9 \u0B85\u0BAE\u0BCD\u0B9A\u0B99\u0BCD\u0B95\u0BB3\u0BC1\u0B9F\u0BA9\u0BCD \u0B85\u0BB1\u0BBF\u0BAE\u0BC1\u0B95\u0BAE\u0BCD",
    slug: "new-techno-mobile-launch",
    summary: "5G \u0BB5\u0BC7\u0B95\u0BAE\u0BCD, 108MP \u0B95\u0BC7\u0BAE\u0BB0\u0BBE \u0BAE\u0BB1\u0BCD\u0BB1\u0BC1\u0BAE\u0BCD \u0BA8\u0BC0\u0BA3\u0BCD\u0B9F \u0BA8\u0BC7\u0BB0 \u0BAA\u0BC7\u0B9F\u0BCD\u0B9F\u0BB0\u0BBF \u0B86\u0BAF\u0BC1\u0BB3\u0BCD. \u0BA8\u0BAE\u0BCD\u0BAA\u0BAE\u0BC1\u0B9F\u0BBF\u0BAF\u0BBE\u0BA4 \u0BB5\u0BBF\u0BB2\u0BC8\u0BAF\u0BBF\u0BB2\u0BCD!",
    content: "<p>\u0B9F\u0BC6\u0B95\u0BCD\u0BA9\u0BCB\u0BB5\u0BBF\u0BA9\u0BCD \u0B9A\u0BAE\u0BC0\u0BAA\u0BA4\u0BCD\u0BA4\u0BBF\u0BAF \u0BB8\u0BCD\u0BAE\u0BBE\u0BB0\u0BCD\u0B9F\u0BCD\u0BAA\u0BCB\u0BA9\u0BCD \u0BAE\u0BC2\u0BB2\u0BAE\u0BCD \u0BA4\u0BCA\u0BB4\u0BBF\u0BB2\u0BCD\u0BA8\u0BC1\u0B9F\u0BCD\u0BAA\u0BA4\u0BCD\u0BA4\u0BBF\u0BA9\u0BCD \u0B85\u0B9F\u0BC1\u0BA4\u0BCD\u0BA4 \u0B95\u0B9F\u0BCD\u0B9F\u0BA4\u0BCD\u0BA4\u0BC8 \u0B85\u0BA9\u0BC1\u0BAA\u0BB5\u0BBF\u0BAF\u0BC1\u0B99\u0BCD\u0B95\u0BB3\u0BCD. \u0B87\u0BA4\u0BC1 \u0B89\u0B99\u0BCD\u0B95\u0BB3\u0BCD \u0BAA\u0BC1\u0B95\u0BC8\u0BAA\u0BCD\u0BAA\u0B9F\u0BAE\u0BCD \u0B8E\u0B9F\u0BC1\u0B95\u0BCD\u0B95\u0BC1\u0BAE\u0BCD \u0BAE\u0BB1\u0BCD\u0BB1\u0BC1\u0BAE\u0BCD \u0B95\u0BC7\u0BAE\u0BBF\u0B99\u0BCD \u0B85\u0BA9\u0BC1\u0BAA\u0BB5\u0BA4\u0BCD\u0BA4\u0BC8 \u0BAE\u0BBE\u0BB1\u0BCD\u0BB1\u0BBF\u0BAF\u0BAE\u0BC8\u0B95\u0BCD\u0B95\u0BC1\u0BAE\u0BCD...</p>",
    coverImageUrl: "https://picsum.photos/seed/ad2/800/400",
    authorId: "u1",
    categoryId: "c1",
    tags: ["\u0BAE\u0BCA\u0BAA\u0BC8\u0BB2\u0BCD", "\u0BA4\u0BCA\u0BB4\u0BBF\u0BB2\u0BCD\u0BA8\u0BC1\u0B9F\u0BCD\u0BAA\u0BAE\u0BCD", "\u0BB5\u0BBF\u0BAE\u0BB0\u0BCD\u0B9A\u0BA9\u0BAE\u0BCD"],
    status: "Published" /* PUBLISHED */,
    publishedAt: "2024-07-21T14:00:00Z",
    views: 8500,
    comments: [],
    isAdvertisement: true
  },
  // Non-Published Articles
  {
    id: "a3",
    title: "\u0BA4\u0BBF \u0B85\u0BA3\u0BCD\u0B9F\u0BB0\u0BCD\u0B9F\u0BBE\u0B95\u0BCD \u0BB8\u0BCD\u0B9F\u0BCB\u0BB0\u0BBF: \u0B89\u0BB3\u0BCD\u0BB3\u0BC2\u0BB0\u0BCD \u0B85\u0BA3\u0BBF \u0B8E\u0BAA\u0BCD\u0BAA\u0B9F\u0BBF \u0B9A\u0BBE\u0BAE\u0BCD\u0BAA\u0BBF\u0BAF\u0BA9\u0BCD\u0BB7\u0BBF\u0BAA\u0BCD\u0BAA\u0BC8 \u0BB5\u0BC6\u0BA9\u0BCD\u0BB1\u0BA4\u0BC1",
    slug: "underdog-championship-win",
    summary: "\u0BB5\u0BBF\u0B9F\u0BBE\u0BAE\u0BC1\u0BAF\u0BB1\u0BCD\u0B9A\u0BBF \u0BAE\u0BB1\u0BCD\u0BB1\u0BC1\u0BAE\u0BCD \u0B95\u0BC1\u0BB4\u0BC1\u0BAA\u0BCD\u0BAA\u0BA3\u0BBF\u0BAF\u0BBF\u0BA9\u0BCD \u0B8E\u0BB4\u0BC1\u0B9A\u0BCD\u0B9A\u0BBF\u0BAF\u0BC2\u0B9F\u0BCD\u0B9F\u0BC1\u0BAE\u0BCD \u0B95\u0BA4\u0BC8.",
    content: "<p>\u0B85\u0BB5\u0BB0\u0BCD\u0B95\u0BB3\u0BCD \u0BB5\u0BC6\u0BB1\u0BCD\u0BB1\u0BBF \u0BAA\u0BC6\u0BB1\u0BC1\u0BB5\u0BBE\u0BB0\u0BCD\u0B95\u0BB3\u0BCD \u0B8E\u0BA9\u0BCD\u0BB1\u0BC1 \u0BAF\u0BBE\u0BB0\u0BC1\u0BAE\u0BCD \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BAA\u0BBE\u0BB0\u0BCD\u0B95\u0BCD\u0B95\u0BB5\u0BBF\u0BB2\u0BCD\u0BB2\u0BC8...</p>",
    coverImageUrl: "https://picsum.photos/seed/a3/800/400",
    authorId: "u3",
    categoryId: "c4",
    tags: ["\u0B95\u0BC2\u0B9F\u0BC8\u0BAA\u0BCD\u0BAA\u0BA8\u0BCD\u0BA4\u0BC1", "\u0B9A\u0BBE\u0BAE\u0BCD\u0BAA\u0BBF\u0BAF\u0BA9\u0BCD\u0BB7\u0BBF\u0BAA\u0BCD", "\u0B89\u0BA4\u0BCD\u0BB5\u0BC7\u0B95\u0BAE\u0BCD"],
    status: "Pending Review" /* PENDING_REVIEW */,
    publishedAt: null,
    views: 0,
    comments: []
  },
  {
    id: "a4",
    title: "\u0BB5\u0BB0\u0BC8\u0BB5\u0BC1: \u0BB5\u0BB0\u0BB5\u0BBF\u0BB0\u0BC1\u0B95\u0BCD\u0B95\u0BC1\u0BAE\u0BCD \u0BA4\u0BC7\u0BB0\u0BCD\u0BA4\u0BB2\u0BCD \u0B95\u0BC1\u0BB1\u0BBF\u0BA4\u0BCD\u0BA4 \u0B86\u0BB0\u0BAE\u0BCD\u0BAA \u0B8E\u0BA3\u0BCD\u0BA3\u0B99\u0BCD\u0B95\u0BB3\u0BCD",
    slug: "draft-election-thoughts",
    summary: "\u0B85\u0BB0\u0B9A\u0BBF\u0BAF\u0BB2\u0BCD \u0BAA\u0BA8\u0BCD\u0BA4\u0BAF\u0BA4\u0BCD\u0BA4\u0BC8 \u0BB5\u0B9F\u0BBF\u0BB5\u0BAE\u0BC8\u0B95\u0BCD\u0B95\u0BC1\u0BAE\u0BCD \u0BB5\u0BC7\u0B9F\u0BCD\u0BAA\u0BBE\u0BB3\u0BB0\u0BCD\u0B95\u0BB3\u0BCD \u0BAE\u0BB1\u0BCD\u0BB1\u0BC1\u0BAE\u0BCD \u0BAE\u0BC1\u0B95\u0BCD\u0B95\u0BBF\u0BAF \u0BAA\u0BBF\u0BB0\u0B9A\u0BCD\u0B9A\u0BBF\u0BA9\u0BC8\u0B95\u0BB3\u0BCD \u0BAA\u0BB1\u0BCD\u0BB1\u0BBF\u0BAF \u0B92\u0BB0\u0BC1 \u0BAA\u0BC2\u0BB0\u0BCD\u0BB5\u0BBE\u0B99\u0BCD\u0B95 \u0BAA\u0BBE\u0BB0\u0BCD\u0BB5\u0BC8.",
    content: "<p>\u0B87\u0BA4\u0BC1 \u0B92\u0BB0\u0BC1 \u0BB5\u0BB0\u0BC8\u0BB5\u0BC1 \u0BAE\u0BB1\u0BCD\u0BB1\u0BC1\u0BAE\u0BCD \u0BB5\u0BC6\u0BB3\u0BBF\u0BAF\u0BC0\u0B9F\u0BCD\u0B9F\u0BBF\u0BB1\u0BCD\u0B95\u0BC1 \u0BA4\u0BAF\u0BBE\u0BB0\u0BBE\u0B95 \u0B87\u0BB2\u0BCD\u0BB2\u0BC8...</p>",
    coverImageUrl: "https://picsum.photos/seed/a4/800/400",
    authorId: "u4",
    categoryId: "c3",
    tags: ["\u0B85\u0BB0\u0B9A\u0BBF\u0BAF\u0BB2\u0BCD", "\u0BA4\u0BC7\u0BB0\u0BCD\u0BA4\u0BB2\u0BCD"],
    status: "Draft" /* DRAFT */,
    publishedAt: null,
    views: 0,
    comments: []
  },
  {
    id: "a6",
    title: "\u0BA4\u0BCA\u0BB1\u0BCD\u0BB1\u0BC1\u0BA8\u0BCB\u0BAF\u0BCD\u0B95\u0BCD\u0B95\u0BC1\u0BAA\u0BCD \u0BAA\u0BBF\u0BA8\u0BCD\u0BA4\u0BC8\u0BAF \u0BAA\u0BA3\u0BBF\u0BAF\u0BBF\u0B9F\u0BA4\u0BCD\u0BA4\u0BBF\u0BB2\u0BCD \u0BB5\u0BB4\u0BBF\u0B9A\u0BC6\u0BB2\u0BC1\u0BA4\u0BCD\u0BA4\u0BB2\u0BCD",
    slug: "post-pandemic-workplace",
    summary: "\u0BA8\u0BBF\u0BB1\u0BC1\u0BB5\u0BA9\u0B99\u0BCD\u0B95\u0BB3\u0BCD \u0B95\u0BB2\u0BAA\u0BCD\u0BAA\u0BBF\u0BA9 \u0BAE\u0BBE\u0BA4\u0BBF\u0BB0\u0BBF\u0B95\u0BB3\u0BC1\u0B9F\u0BA9\u0BCD \u0BAA\u0BB0\u0BBF\u0B9A\u0BCB\u0BA4\u0BA9\u0BC8 \u0B9A\u0BC6\u0BAF\u0BCD\u0B95\u0BBF\u0BA9\u0BCD\u0BB1\u0BA9.",
    content: "<p>\u0B92\u0BB0\u0BC1 \u0B95\u0BA9\u0B9A\u0BA4\u0BC1\u0BB0\u0BA4\u0BCD\u0BA4\u0BBF\u0BB2\u0BCD \u0B92\u0BA9\u0BCD\u0BAA\u0BA4\u0BC1 \u0BAE\u0BC1\u0BA4\u0BB2\u0BCD \u0B90\u0BA8\u0BCD\u0BA4\u0BC1 \u0BB5\u0BB0\u0BC8 \u0B8E\u0BA9\u0BCD\u0BAA\u0BA4\u0BC1 \u0BAA\u0BB2\u0BB0\u0BC1\u0B95\u0BCD\u0B95\u0BC1 \u0B92\u0BB0\u0BC1 \u0BA8\u0BBF\u0BA9\u0BC8\u0BB5\u0BC1\u0B9A\u0BCD\u0B9A\u0BBF\u0BA9\u0BCD\u0BA9\u0BAE\u0BCD...</p>",
    coverImageUrl: "https://picsum.photos/seed/a6/800/400",
    authorId: "u4",
    categoryId: "c2",
    tags: ["\u0BB5\u0BC7\u0BB2\u0BC8", "\u0BB5\u0BA3\u0BBF\u0B95\u0BAE\u0BCD", "\u0BB5\u0BC7\u0BB2\u0BC8\u0BAF\u0BBF\u0BA9\u0BCD \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0B95\u0BBE\u0BB2\u0BAE\u0BCD"],
    status: "Rejected" /* REJECTED */,
    publishedAt: null,
    views: 0,
    comments: [],
    rejectionReason: "Needs more specific data and sources to support the claims."
  },
  {
    id: "a15",
    title: "\u0BA8\u0B95\u0BB0\u0BCD\u0BAA\u0BCD\u0BAA\u0BC1\u0BB1 \u0BA4\u0BCB\u0B9F\u0BCD\u0B9F\u0B95\u0BCD\u0B95\u0BB2\u0BC8: \u0B9A\u0BBF\u0BB1\u0BBF\u0BAF \u0B87\u0B9F\u0B99\u0BCD\u0B95\u0BB3\u0BBF\u0BB2\u0BCD \u0B89\u0B99\u0BCD\u0B95\u0BB3\u0BCD \u0B9A\u0BCA\u0BA8\u0BCD\u0BA4 \u0B89\u0BA3\u0BB5\u0BC8 \u0BB5\u0BB3\u0BB0\u0BCD\u0BAA\u0BCD\u0BAA\u0BA4\u0BC1",
    slug: "urban-gardening-guide",
    summary: "\u0BAA\u0BBE\u0BB2\u0BCD\u0B95\u0BA9\u0BBF\u0B95\u0BB3\u0BCD \u0BAE\u0BB1\u0BCD\u0BB1\u0BC1\u0BAE\u0BCD \u0B9C\u0BA9\u0BCD\u0BA9\u0BB2\u0BCD \u0B93\u0BB0\u0B99\u0BCD\u0B95\u0BB3\u0BBF\u0BB2\u0BCD \u0B95\u0BBE\u0BAF\u0BCD\u0B95\u0BB1\u0BBF\u0B95\u0BB3\u0BCD \u0BAE\u0BB1\u0BCD\u0BB1\u0BC1\u0BAE\u0BCD \u0BAE\u0BC2\u0BB2\u0BBF\u0B95\u0BC8\u0B95\u0BB3\u0BC8 \u0BB5\u0BB3\u0BB0\u0BCD\u0BAA\u0BCD\u0BAA\u0BA4\u0BB1\u0BCD\u0B95\u0BBE\u0BA9 \u0B92\u0BB0\u0BC1 \u0BA4\u0BCA\u0B9F\u0B95\u0BCD\u0B95 \u0BB5\u0BB4\u0BBF\u0B95\u0BBE\u0B9F\u0BCD\u0B9F\u0BBF.",
    content: "<p>\u0B87\u0B9F\u0BAA\u0BCD \u0BAA\u0BB1\u0BCD\u0BB1\u0BBE\u0B95\u0BCD\u0B95\u0BC1\u0BB1\u0BC8 \u0B92\u0BB0\u0BC1 \u0BA4\u0B9F\u0BC8\u0BAF\u0BBE\u0B95 \u0B87\u0BB0\u0BC1\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BBF\u0BAF\u0BA4\u0BBF\u0BB2\u0BCD\u0BB2\u0BC8. \u0B87\u0BA8\u0BCD\u0BA4 \u0BB5\u0BB4\u0BBF\u0B95\u0BBE\u0B9F\u0BCD\u0B9F\u0BBF \u0B89\u0B99\u0BCD\u0B95\u0BB3\u0BCD \u0B9A\u0BCA\u0BA8\u0BCD\u0BA4 \u0B9A\u0BAE\u0BC8\u0BAF\u0BB2\u0BB1\u0BC8 \u0BA4\u0BCB\u0B9F\u0BCD\u0B9F\u0BA4\u0BCD\u0BA4\u0BC8 \u0B85\u0BAE\u0BC8\u0B95\u0BCD\u0B95 \u0B89\u0BA4\u0BB5\u0BC1\u0BAE\u0BCD...</p>",
    coverImageUrl: "https://picsum.photos/seed/a15/800/400",
    authorId: "u7",
    categoryId: "c8",
    tags: ["\u0BA4\u0BCB\u0B9F\u0BCD\u0B9F\u0B95\u0BCD\u0B95\u0BB2\u0BC8", "\u0BB5\u0BBE\u0BB4\u0BCD\u0B95\u0BCD\u0B95\u0BC8 \u0BAE\u0BC1\u0BB1\u0BC8", "DIY"],
    status: "Pending Review" /* PENDING_REVIEW */,
    publishedAt: null,
    views: 0,
    comments: []
  },
  {
    id: "a16",
    title: "\u0BB5\u0BB0\u0BC8\u0BB5\u0BC1: \u0BAA\u0BC1\u0BA4\u0BBF\u0BAF \u0B95\u0BC7\u0BAE\u0BBF\u0B99\u0BCD \u0B95\u0BA9\u0BCD\u0B9A\u0BCB\u0BB2\u0BCD \u0BAA\u0BB1\u0BCD\u0BB1\u0BBF\u0BAF \u0BAE\u0BC1\u0BA4\u0BB2\u0BCD \u0BAA\u0BA4\u0BBF\u0BB5\u0BC1\u0B95\u0BB3\u0BCD",
    slug: "draft-gaming-console-review",
    summary: '\u0BB5\u0BB0\u0BB5\u0BBF\u0BB0\u0BC1\u0B95\u0BCD\u0B95\u0BC1\u0BAE\u0BCD "\u0BAA\u0BBF\u0BB3\u0BC7\u0BB8\u0BCD\u0B9F\u0BC7\u0BB7\u0BA9\u0BCD 6" \u0BAA\u0BB1\u0BCD\u0BB1\u0BBF\u0BAF \u0B86\u0BB0\u0BAE\u0BCD\u0BAA\u0B95\u0B9F\u0BCD\u0B9F \u0B9A\u0BBF\u0BA8\u0BCD\u0BA4\u0BA9\u0BC8\u0B95\u0BB3\u0BCD \u0BAE\u0BB1\u0BCD\u0BB1\u0BC1\u0BAE\u0BCD \u0BB5\u0BA4\u0BA8\u0BCD\u0BA4\u0BBF\u0B95\u0BB3\u0BCD.',
    content: "<p>\u0B87\u0BA9\u0BCD\u0BA9\u0BC1\u0BAE\u0BCD \u0B89\u0BB1\u0BC1\u0BA4\u0BBF\u0BAA\u0BCD\u0BAA\u0B9F\u0BC1\u0BA4\u0BCD\u0BA4\u0BAA\u0BCD\u0BAA\u0B9F\u0BB5\u0BBF\u0BB2\u0BCD\u0BB2\u0BC8, \u0B86\u0BA9\u0BBE\u0BB2\u0BCD \u0B95\u0B9A\u0BBF\u0BB5\u0BC1\u0B95\u0BB3\u0BCD \u0B92\u0BB0\u0BC1 \u0B9A\u0B95\u0BCD\u0BA4\u0BBF\u0BB5\u0BBE\u0BAF\u0BCD\u0BA8\u0BCD\u0BA4 \u0BAA\u0BC1\u0BA4\u0BBF\u0BAF \u0B9A\u0BBF\u0BAA\u0BCD \u0BAE\u0BB1\u0BCD\u0BB1\u0BC1\u0BAE\u0BCD \u0B85\u0BA4\u0BBF\u0BB5\u0BC7\u0B95 \u0B95\u0BBF\u0BB0\u0BBE\u0BAA\u0BBF\u0B95\u0BCD\u0BB8\u0BCD \u0B86\u0B95\u0BBF\u0BAF\u0BB5\u0BB1\u0BCD\u0BB1\u0BC8\u0B95\u0BCD \u0B95\u0BC1\u0BB1\u0BBF\u0BAA\u0BCD\u0BAA\u0BBF\u0B9F\u0BC1\u0B95\u0BBF\u0BA9\u0BCD\u0BB1\u0BA9...</p>",
    coverImageUrl: "https://picsum.photos/seed/a16/800/400",
    authorId: "u3",
    categoryId: "c1",
    tags: ["\u0B95\u0BC7\u0BAE\u0BBF\u0B99\u0BCD", "\u0BA4\u0BCA\u0BB4\u0BBF\u0BB2\u0BCD\u0BA8\u0BC1\u0B9F\u0BCD\u0BAA\u0BAE\u0BCD"],
    status: "Draft" /* DRAFT */,
    publishedAt: null,
    views: 0,
    comments: []
  }
];
var notifications = [
  {
    id: "n1",
    userId: "u3",
    // அருண்
    articleId: "a1",
    message: 'Congratulations! Your article "\u0B9A\u0BC6\u0BAF\u0BB1\u0BCD\u0B95\u0BC8 \u0BA8\u0BC1\u0BA3\u0BCD\u0BA3\u0BB1\u0BBF\u0BB5\u0BBF\u0BA9\u0BCD \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0B95\u0BBE\u0BB2\u0BAE\u0BCD: 2024 \u0B87\u0BB2\u0BCD \u0B95\u0BB5\u0BA9\u0BBF\u0B95\u0BCD\u0B95 \u0BB5\u0BC7\u0BA3\u0BCD\u0B9F\u0BBF\u0BAF \u0BAA\u0BCB\u0B95\u0BCD\u0B95\u0BC1\u0B95\u0BB3\u0BCD" has been approved and published.',
    type: "APPROVED" /* APPROVED */,
    read: false,
    timestamp: "2024-07-22T10:05:00Z"
  },
  {
    id: "n2",
    userId: "u4",
    // ரீட்டா
    articleId: "a6",
    message: 'Your article "\u0BA4\u0BCA\u0BB1\u0BCD\u0BB1\u0BC1\u0BA8\u0BCB\u0BAF\u0BCD\u0B95\u0BCD\u0B95\u0BC1\u0BAA\u0BCD \u0BAA\u0BBF\u0BA8\u0BCD\u0BA4\u0BC8\u0BAF \u0BAA\u0BA3\u0BBF\u0BAF\u0BBF\u0B9F\u0BA4\u0BCD\u0BA4\u0BBF\u0BB2\u0BCD \u0BB5\u0BB4\u0BBF\u0B9A\u0BC6\u0BB2\u0BC1\u0BA4\u0BCD\u0BA4\u0BB2\u0BCD" has been rejected. Reason: Needs more specific data and sources.',
    type: "REJECTED" /* REJECTED */,
    read: false,
    timestamp: "2024-07-21T14:00:00Z"
  },
  {
    id: "n3",
    userId: "u3",
    // அருண்
    articleId: "a3",
    message: 'A new comment was posted on your article "\u0BA4\u0BBF \u0B85\u0BA3\u0BCD\u0B9F\u0BB0\u0BCD\u0B9F\u0BBE\u0B95\u0BCD \u0BB8\u0BCD\u0B9F\u0BCB\u0BB0\u0BBF: \u0B89\u0BB3\u0BCD\u0BB3\u0BC2\u0BB0\u0BCD \u0B85\u0BA3\u0BBF \u0B8E\u0BAA\u0BCD\u0BAA\u0B9F\u0BBF \u0B9A\u0BBE\u0BAE\u0BCD\u0BAA\u0BBF\u0BAF\u0BA9\u0BCD\u0BB7\u0BBF\u0BAA\u0BCD\u0BAA\u0BC8 \u0BB5\u0BC6\u0BA9\u0BCD\u0BB1\u0BA4\u0BC1".',
    type: "COMMENT" /* COMMENT */,
    read: true,
    timestamp: "2024-07-23T09:15:00Z"
  },
  {
    id: "n4",
    userId: "u4",
    // ரீட்டா
    articleId: "a2",
    message: 'Congratulations! Your article "\u0BAA\u0BC1\u0BA4\u0BBF\u0BAF \u0BAA\u0BCA\u0BB0\u0BC1\u0BB3\u0BBE\u0BA4\u0BBE\u0BB0\u0B95\u0BCD \u0B95\u0BCA\u0BB3\u0BCD\u0B95\u0BC8\u0B95\u0BB3\u0BC1\u0B95\u0BCD\u0B95\u0BC1 \u0B89\u0BB2\u0B95\u0B9A\u0BCD \u0B9A\u0BA8\u0BCD\u0BA4\u0BC8\u0B95\u0BB3\u0BCD \u0B8E\u0BA4\u0BBF\u0BB0\u0BCD\u0BB5\u0BBF\u0BA9\u0BC8" has been approved and published.',
    type: "APPROVED" /* APPROVED */,
    read: true,
    timestamp: "2024-07-22T09:35:00Z"
  }
];
var subscribers = [
  { id: "sub1", email: "reader1@example.com", subscribedAt: "2024-07-20T10:00:00Z" },
  { id: "sub2", email: "newsfan@example.com", subscribedAt: "2024-07-21T11:30:00Z" },
  { id: "sub3", email: "johndoe@example.com", subscribedAt: "2024-07-22T15:00:00Z" },
  { id: "sub4", email: "test.user@example.com", subscribedAt: "2024-07-23T09:00:00Z" }
];

// src/handlers.ts
var respond = (statusCode, body) => ({
  statusCode,
  headers: {
    "Content-Type": "application/json"
  },
  body: JSON.stringify(body)
});
var login = async (event) => {
  const { email } = JSON.parse(event.body || "{}");
  const user = users.find((u) => u.email === email);
  return respond(200, user || null);
};
var register = async (event) => {
  const { name, email } = JSON.parse(event.body || "{}");
  const isFirstUser = users.length === 0;
  const newUser = {
    id: `u${users.length + 1}`,
    name,
    email,
    role: isFirstUser ? "ADMIN" /* ADMIN */ : "AUTHOR" /* AUTHOR */,
    avatarUrl: `https://picsum.photos/seed/u${users.length + 1}/100/100`
  };
  users.push(newUser);
  return respond(201, newUser);
};
var getUsers = async () => respond(200, users);
var getUser = async (event) => {
  const { id } = event.pathParameters || {};
  return respond(200, users.find((u) => u.id === id));
};
var createUser = async (event) => {
  const userData = JSON.parse(event.body || "{}");
  const newUser = {
    id: `u${users.length + 1}`,
    name: userData.name || "New User",
    email: userData.email || "",
    role: userData.role || "AUTHOR" /* AUTHOR */,
    avatarUrl: userData.avatarUrl || `https://picsum.photos/seed/u${users.length + 1}/100/100`
  };
  users.push(newUser);
  return respond(201, newUser);
};
var updateUser = async (event) => {
  const { id } = event.pathParameters || {};
  const userData = JSON.parse(event.body || "{}");
  const userIndex = users.findIndex((u) => u.id === id);
  if (userIndex === -1)
    return respond(404, { message: "User not found" });
  users[userIndex] = { ...users[userIndex], ...userData };
  return respond(200, users[userIndex]);
};
var deleteUser = async (event) => {
  const { id } = event.pathParameters || {};
  const userIndex = users.findIndex((u) => u.id === id);
  if (userIndex === -1) {
    return respond(404, { message: "User not found" });
  }
  users.splice(userIndex, 1);
  return respond(204, null);
};
var getArticles = async (event) => {
  const params = event.queryStringParameters || {};
  let results = [...articles];
  if (params) {
    if (params.categorySlug) {
      const category = categories.find((c) => c.slug === params.categorySlug);
      if (category)
        results = results.filter((a) => a.categoryId === category.id);
    }
    if (params.categoryId)
      results = results.filter((a) => a.categoryId === params.categoryId);
    if (params.tag)
      results = results.filter((a) => a.tags.map((t) => t.toLowerCase()).includes(params.tag.toLowerCase()));
    if (params.authorId)
      results = results.filter((a) => a.authorId === params.authorId);
    if (params.query) {
      const q = params.query.toLowerCase();
      results = results.filter((a) => a.title.toLowerCase().includes(q) || a.summary.toLowerCase().includes(q));
    }
    if (params.status && params.status !== "ALL") {
      results = results.filter((a) => a.status === params.status);
    } else if (!params?.status || params.status !== "ALL") {
      results = results.filter((a) => a.status === "Published" /* PUBLISHED */);
    }
    if (params.featured)
      results = results.filter((a) => a.isFeatured === (params.featured === "true"));
    if (params.isAdvertisement)
      results = results.filter((a) => !!a.isAdvertisement === (params.isAdvertisement === "true"));
    if (params.limit)
      results = results.slice(0, parseInt(params.limit, 10));
  } else {
    results = results.filter((a) => a.status === "Published" /* PUBLISHED */);
  }
  return respond(200, results);
};
var getArticleById = async (event) => {
  const { id } = event.pathParameters || {};
  return respond(200, articles.find((a) => a.id === id));
};
var getArticleBySlug = async (event) => {
  const { slug } = event.pathParameters || {};
  return respond(200, articles.find((a) => a.slug === slug));
};
var createArticle = async (event) => {
  const articleData = JSON.parse(event.body || "{}");
  const newArticle = {
    id: `a${articles.length + 1}`,
    title: articleData.title || "Untitled",
    slug: articleData.title?.toLowerCase().replace(/\s+/g, "-") || `a${articles.length + 1}`,
    summary: articleData.summary || "",
    content: articleData.content || "",
    coverImageUrl: articleData.coverImageUrl || "https://picsum.photos/seed/new/800/400",
    authorId: articleData.authorId || "",
    categoryId: articleData.categoryId || "",
    tags: articleData.tags || [],
    status: articleData.status || "Draft" /* DRAFT */,
    publishedAt: null,
    views: 0,
    comments: [],
    ...articleData
  };
  articles.unshift(newArticle);
  return respond(201, newArticle);
};
var updateArticle = async (event) => {
  const { id } = event.pathParameters || {};
  const articleData = JSON.parse(event.body || "{}");
  const articleIndex = articles.findIndex((a) => a.id === id);
  if (articleIndex === -1)
    return respond(404, { message: "Article not found" });
  articles[articleIndex] = { ...articles[articleIndex], ...articleData };
  return respond(200, articles[articleIndex]);
};
var deleteArticle = async (event) => {
  const { id } = event.pathParameters || {};
  const articleIndex = articles.findIndex((a) => a.id === id);
  if (articleIndex === -1) {
    return respond(404, { message: "Article not found" });
  }
  articles.splice(articleIndex, 1);
  return respond(204, null);
};
var updateArticleStatus = async (event) => {
  const { id } = event.pathParameters || {};
  const { status, reason } = JSON.parse(event.body || "{}");
  const articleIndex = articles.findIndex((a) => a.id === id);
  if (articleIndex === -1)
    return respond(404, { message: "Article not found" });
  articles[articleIndex].status = status;
  if (status === "Rejected" /* REJECTED */)
    articles[articleIndex].rejectionReason = reason;
  return respond(200, articles[articleIndex]);
};
var updateFeaturedStatus = async (event) => {
  const { updates } = JSON.parse(event.body || "{}");
  (updates || []).forEach((update) => {
    const articleIndex = articles.findIndex((a) => a.id === update.articleId);
    if (articleIndex !== -1)
      articles[articleIndex].isFeatured = update.isFeatured;
  });
  return respond(204, null);
};
var getCategories = async () => respond(200, categories);
var createCategory = async (event) => {
  const catData = JSON.parse(event.body || "{}");
  const newCategory = { id: `c${categories.length + 1}`, ...catData };
  categories.push(newCategory);
  return respond(201, newCategory);
};
var updateCategory = async (event) => {
  const { id } = event.pathParameters || {};
  const catData = JSON.parse(event.body || "{}");
  const catIndex = categories.findIndex((c) => c.id === id);
  if (catIndex === -1)
    return respond(404, { message: "Category not found" });
  categories[catIndex] = { ...categories[catIndex], ...catData };
  return respond(200, categories[catIndex]);
};
var deleteCategory = async (event) => {
  const { id } = event.pathParameters || {};
  const catIndex = categories.findIndex((c) => c.id === id);
  if (catIndex !== -1) {
    categories.splice(catIndex, 1);
  }
  return respond(204, null);
};
var getPendingComments = async () => {
  const pending = [];
  articles.forEach((article) => {
    article.comments.forEach((comment) => {
      if (comment.status === "PENDING")
        pending.push({ ...comment, article });
    });
  });
  return respond(200, pending);
};
var postComment = async (event) => {
  const { id } = event.pathParameters || {};
  const { text } = JSON.parse(event.body || "{}");
  const articleIndex = articles.findIndex((a) => a.id === id);
  if (articleIndex === -1)
    return respond(404, { message: "Article not found" });
  const newComment = {
    id: `com${v4_default()}`,
    authorName: "Anonymous User",
    authorAvatarUrl: `https://picsum.photos/seed/${v4_default()}/50/50`,
    text,
    date: (/* @__PURE__ */ new Date()).toISOString(),
    status: "PENDING"
  };
  articles[articleIndex].comments.push(newComment);
  return respond(201, newComment);
};
var updateCommentStatus = async (event) => {
  const { articleId, commentId } = event.pathParameters || {};
  const { status } = JSON.parse(event.body || "{}");
  const articleIndex = articles.findIndex((a) => a.id === articleId);
  if (articleIndex === -1)
    return respond(404, { message: "Article not found" });
  const commentIndex = articles[articleIndex].comments.findIndex((c) => c.id === commentId);
  if (commentIndex === -1)
    return respond(404, { message: "Comment not found" });
  articles[articleIndex].comments[commentIndex].status = status;
  return respond(204, null);
};
var getNotificationsForUser = async (event) => {
  const { userId } = event.pathParameters || {};
  return respond(200, notifications.filter((n) => n.userId === userId));
};
var getAllTags = async () => {
  const tagCounts = /* @__PURE__ */ new Map();
  articles.forEach((article) => {
    article.tags.forEach((tag) => {
      const lowerCaseTag = tag.toLowerCase();
      tagCounts.set(lowerCaseTag, (tagCounts.get(lowerCaseTag) || 0) + 1);
    });
  });
  const result = Array.from(tagCounts.entries()).map(([name, count]) => ({ name, count })).sort((a, b) => b.count - a.count);
  return respond(200, result);
};
var getSubscribers = async () => respond(200, subscribers);
var subscribe = async (event) => {
  const { email } = JSON.parse(event.body || "{}");
  const newSubscriber = {
    id: `sub${subscribers.length + 1}`,
    email,
    subscribedAt: (/* @__PURE__ */ new Date()).toISOString()
  };
  subscribers.push(newSubscriber);
  return respond(201, newSubscriber);
};
var contact = async (event) => {
  console.log("Contact form submitted (mock):", JSON.parse(event.body || "{}"));
  return respond(204, null);
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  contact,
  createArticle,
  createCategory,
  createUser,
  deleteArticle,
  deleteCategory,
  deleteUser,
  getAllTags,
  getArticleById,
  getArticleBySlug,
  getArticles,
  getCategories,
  getNotificationsForUser,
  getPendingComments,
  getSubscribers,
  getUser,
  getUsers,
  login,
  postComment,
  register,
  subscribe,
  updateArticle,
  updateArticleStatus,
  updateCategory,
  updateCommentStatus,
  updateFeaturedStatus,
  updateUser
});
